(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[1],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_core_js_object_entries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/core-js/object/entries */ "./node_modules/@babel/runtime/core-js/object/entries.js");
/* harmony import */ var _babel_runtime_core_js_object_entries__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_core_js_object_entries__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _DataViewSidebar_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../DataViewSidebar.vue */ "./resources/js/src/views/apps/projects/DataViewSidebar.vue");
/* harmony import */ var _data_list_moduleDataList_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../data-list/moduleDataList.js */ "./resources/js/src/views/apps/projects/data-list/moduleDataList.js");

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

 // import VuePerfectScrollbar from 'vue-perfect-scrollbar'

/* harmony default export */ __webpack_exports__["default"] = ({
  props: {
    isSidebarActive: {
      type: Boolean,
      required: true
    },
    data: {
      type: Object,
      default: function _default() {}
    }
  },
  data: function data() {
    return {
      orgActiveForm: false,
      oldImage: true,
      logoToChange: null,
      popupActive: false,
      orgForm: new Form({
        name: '',
        email: '',
        phone: '',
        website: '',
        address: '',
        logo: null,
        account_id: null
      }),
      orgFormEdit: new Form({
        name: '',
        email: '',
        phone: '',
        website: '',
        address: '',
        logo: null,
        account_id: null
      }),
      // kk
      // statusFa: {
      //   on_hold: 'درجریان',
      //   delivered: 'تکمیل',
      //   canceled: 'نا موفق',
      // },
      clients: [],
      client: [],
      itemsPerPage: 4 // isMounted: false,
      // addNewDataSidebar: false,
      // sidebarData: {},
      // ll
      // dataId: null,
      // dataName: '',
      // dataCategory: null,
      // dataOrder_status: 'pending',
      // dataPrice: 0,
      // settings: { // perfectscrollbar settings
      //   maxScrollbarLength: 60,
      //   wheelSpeed: .60
      // }

    };
  },
  components: {// DataViewSidebar,
    // VuePerfectScrollbar
  },
  created: function created() {
    // if (!moduleDataList.isRegistered) {
    //   this.$store.registerModule('dataList', moduleDataList)
    //   moduleDataList.isRegistered = true
    // }
    // this.$store.dispatch('dataList/fetchDataListItems'),
    this.getData();
  },
  watch: {
    isSidebarActive: function isSidebarActive(val) {
      if (!val) return;

      if (_babel_runtime_core_js_object_entries__WEBPACK_IMPORTED_MODULE_0___default()(this.data).length === 0) {
        // this.initValues()
        this.$validator.reset();
      } else {} // const { category, id, img, name, order_status, price } = JSON.parse(JSON.stringify(this.data))
      // this.dataId = id
      // this.dataCategory = category
      // this.orgForm.logo = img
      // this.dataName = name
      // this.dataOrder_status = order_status
      // this.dataPrice = price
      // this.initValues()
      // Object.entries(this.data).length === 0 ? this.initValues() : { this.dataId, this.dataName, this.dataCategory, this.dataOrder_status, this.dataPrice } = JSON.parse(JSON.stringify(this.data))

    }
  },
  computed: {
    isSidebarActiveLocal: {
      get: function get() {
        return this.isSidebarActive;
      },
      set: function set(val) {
        if (!val) {
          this.$emit('closeSidebar'), this.$emit('customEvent', this.clients.find(function (e) {
            return !!e;
          }));
        }
      }
    },
    // scrollbarTag() { return this.$store.getters.scrollbarTag },
    // scrollbarTag() { return this.$store.state.is_touch_device ? 'div' : 'VuePerfectScrollbar' },
    // currentPage() {
    //   if (this.isMounted) {
    //     return this.$refs.table.currentx
    //   }
    //   return 0
    // },
    // clients() {
    //   return this.$store.state.dataList.clients
    // },
    queriedItems: function queriedItems() {
      return this.$refs.table ? this.$refs.table.queriedResults.length : this.clients.length;
    }
  },
  methods: {
    getData: function getData() {
      var _this = this;

      this.$Progress.start();
      this.axios.get('/api/clients').then(function (response) {
        _this.clients = response.data;

        _this.$Progress.set(100);
      });
    },
    resetAllState: function resetAllState() {
      this.oldImage == true;
      this.orgActiveForm = false;
      this.orgFormEdit.reset();
    },
    deletOnChangeLogo: function deletOnChangeLogo() {
      this.logoToChange = null;
      this.oldImage = true;
    },
    showClientData: function showClientData(id) {
      var _this2 = this;

      // console.log('ID', id);
      this.orgActiveForm = false;
      this.orgForm.get('/api/clients/' + id).then(function (response) {
        _this2.client = response.data;

        _this2.$Progress.set(100);

        _this2.popupActive = true;
      });
    },
    updateData: function updateData() {
      var _this3 = this;

      if (!(this.logoToChange == null)) {
        this.orgFormEdit.logo = this.logoToChange;
      }

      this.orgFormEdit.put('/api/clients/' + this.orgFormEdit.id).then(function (_ref) {
        var data = _ref.data;

        // Finish the Progress Bar
        _this3.getData();

        _this3.resetAllState(); // toast notification


        _this3.$vs.notify({
          title: 'موفقیت!',
          text: 'نهاد مذکور موفقانه آپدیت شد.',
          color: 'success',
          iconPack: 'feather',
          icon: 'icon-check',
          position: 'top-right'
        });
      });
    },
    // isFormValid() {
    // },
    submitData: function submitData() {
      var _this4 = this;

      // console.log('Edit Form', this.orgForm.logo)
      this.orgForm.post('/api/clients').then(function (_ref2) {
        var data = _ref2.data;

        _this4.getData();

        _this4.$vs.notify({
          title: 'موفقیت!',
          text: 'نهاد موفقانه ثبت سیستم شد.',
          color: 'success',
          iconPack: 'feather',
          icon: 'icon-check',
          position: 'top-right'
        });

        _this4.orgForm.reset();
      }).catch(function (errors) {
        _this4.$Progress.set(100);

        _this4.$vs.notify({
          title: 'ناموفق!',
          text: 'لطفاً معلومات نهاد را چک کنید و دوباره امتحان کنید!',
          color: 'danger',
          iconPack: 'feather',
          icon: 'icon-cross',
          position: 'top-right'
        });
      }); // this.$validator.validateAll().then(result => {
      //   if (result) {
      //     const obj = {
      //       id: this.dataId,
      //       name: this.dataName,
      //       img: this.orgForm.logo,
      //       category: this.dataCategory,
      //       order_status: this.dataOrder_status,
      //       price: this.dataPrice
      //     }
      //     if (this.dataId !== null && this.dataId >= 0) {
      //       this.$store.dispatch('dataList/updateItem', obj).catch(err => { console.error(err) })
      //     } else {
      //       delete obj.id
      //       obj.popularity = 0
      //       this.$store.dispatch('dataList/addItem', obj).catch(err => { console.error(err) })
      //     }
      //     this.$emit('closeSidebar')
      //     this.initValues()
      //   }
      // })
    },
    updateCurrImg: function updateCurrImg(input) {
      var _this5 = this;

      if (input.target.files && input.target.files[0]) {
        // this.oldImage = false
        var reader = new FileReader();

        reader.onload = function (e) {
          _this5.orgForm.logo = e.target.result; // this.logoToChange = e.target.result
        };

        reader.readAsDataURL(input.target.files[0]);
      }
    },
    updateCurrImg1: function updateCurrImg1(input) {
      var _this6 = this;

      if (input.target.files && input.target.files[0]) {
        this.oldImage = false;
        var reader = new FileReader();

        reader.onload = function (e) {
          // this.orgForm.logo = e.target.result
          _this6.logoToChange = e.target.result;
        };

        reader.readAsDataURL(input.target.files[0]);
      }
    },
    goTo: function goTo(data) {
      this.$router.push({
        path: '/projects/project/${data.id}',
        name: 'project-view',
        params: {
          id: data.id,
          dyTitle: data.name
        }
      }).catch(function () {});
    },
    viewProject: function viewProject(id) {
      // Vue.$forceUpdate();
      this.$router.push('/projects/project/' + id).catch(function () {});
    },
    // End Custom
    // addNewData() {
    //   this.sidebarData = {}
    //   this.toggleDataSidebar(true)
    // },
    deleteData: function deleteData(id) {
      var _this7 = this;

      // this.$store.dispatch('dataList/removeItem', id).catch(err => { console.error(err) })
      this.orgActiveForm = false;
      swal.fire({
        title: 'آیا مطمیٔن هستید؟',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: 'rgb(54 34 119)',
        cancelButtonColor: 'rgb(229 83 85)',
        confirmButtonText: '<span>بله، حذف شود!</span>',
        cancelButtonText: '<span>نخیر، لغو عملیه!</span>'
      }).then(function (result) {
        if (result.isConfirmed) {
          _this7.orgForm.delete('/api/clients/' + id).then(function (id) {
            swal.fire({
              title: 'عملیه حذف موفقانه انجام شد.',
              icon: 'success'
            });

            _this7.getData();

            _this7.resetAllState();
          }).catch(function () {});
        }
      });
    },
    editData: function editData(data) {
      // this.sidebarData = JSON.parse(JSON.stringify(this.blankData))
      // this.sidebarData = data
      // this.toggleDataSidebar(true)
      this.orgActiveForm = true;
      this.orgFormEdit.name = data.name;
      this.orgFormEdit.email = data.email;
      this.orgFormEdit.phone = data.phone;
      this.orgFormEdit.website = data.website;
      this.orgFormEdit.address = data.address;
      this.orgFormEdit.logo = data.logo;
      this.orgFormEdit.id = data.id;
    },
    getOrderStatusColor: function getOrderStatusColor(status) {
      if (status === 'on_hold') return 'warning';
      if (status === 'delivered') return 'success';
      if (status === 'canceled') return 'danger';
      return 'primary';
    },
    getPopularityColor: function getPopularityColor(num) {
      if (num > 90) return 'success';
      if (num > 70) return 'primary';
      if (num >= 50) return 'warning';
      if (num < 50) return 'danger';
      return 'primary';
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/core-js/object/keys */ "./node_modules/@babel/runtime/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_1__);

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: "vx-ekmalat",
  props: ["items", "form"],
  data: function data() {
    return {
      operations: [],
      density: null,
      item_types: [],
      mesure_unit: [],
      goods: []
    };
  },
  created: function created() {
    this.getOperations();
    this.getAllItems();
    this.getAllUnites();
  },
  methods: {
    datacalled: function datacalled(data) {
      console.log(data.uom_equiv_id);
    },
    operationChange: function operationChange() {// console.log(this.items[0]['operation_id']['id'] == 1);
    },
    getOperations: function getOperations() {
      var _this = this;

      this.$Progress.start();
      this.axios.get("/api/operation").then(function (response) {
        _this.operations = response.data;
      });
    },
    getItemTypes: function getItemTypes() {
      var _this2 = this;

      this.$Progress.start();
      this.axios.get("/api/item-type").then(function (response) {
        _this2.item_types = response.data;
      });
    },
    // for items to be bought
    getAllItems: function getAllItems() {
      var _this3 = this;

      this.$Progress.start();
      this.axios.get('/api/items').then(function (response) {
        _this3.goods = response.data;
      });
    },
    // for getting measure unit of the item
    getAllUnites: function getAllUnites() {
      var _this4 = this;

      this.axios.get('/api/m-units').then(function (response) {
        _this4.mesure_unit = response.data;
      });
    },
    addNewRow: function addNewRow() {
      console.log("this.items", this.items);
      this.items.push({
        item_id: "",
        operation_id: null,
        equivalent: "",
        ammount: "",
        unit_price: "",
        total_price: "",
        density: null
      });
    },
    findUom: function findUom(id, field) {
      var _this5 = this;

      var unit = null;

      _babel_runtime_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(this.goods).some(function (key) {
        return _this5.goods[key].id == id ? unit = _this5.goods[key][field] : '';
      });

      var resp = '';

      _babel_runtime_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(this.mesure_unit).some(function (key) {
        return _this5.mesure_unit[key].id == unit ? resp = _this5.mesure_unit[key].acronym : '';
      });

      return resp;
    },
    removeRow: function removeRow() {
      var _this6 = this;

      swal.fire({
        title: 'آیا متمعن هستید؟',
        text: "جنس مورد نظر حذف خواهد شد",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: 'rgb(54 34 119)',
        cancelButtonColor: 'rgb(229 83 85)',
        confirmButtonText: '<span>بله، حذف شود!</span>',
        cancelButtonText: '<span>نخیر، لغو عملیه!</span>'
      }).then(function (result) {
        if (result.isConfirmed) {
          var id = _this6.items[_this6.items.length - 1].id;

          _this6.axios.delete('/api/pro-item/' + id).then(function (id) {
            swal.fire({
              title: 'عملیه موفقانه انجام شد.',
              text: "جنس مورد نظر از سیستم پاک شد!",
              icon: 'success'
            });

            if (_this6.items.length > 1) {
              _this6.items.splice(_this6.items.length - 1, 1);
            }
          }).catch(function () {});
        }
      });
    }
  },
  // End Of methods
  watch: {// console.log(this.items);
  },
  components: {
    "v-select": vue_select__WEBPACK_IMPORTED_MODULE_1___default.a
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".add-new-data-sidebar[data-v-c60db430]  .vs-sidebar--background {\n  z-index: 52010;\n}\n.add-new-data-sidebar[data-v-c60db430]  .vs-sidebar {\n  z-index: 52010;\n  width: 600px;\n  max-width: 90vw;\n}\n[dir] .add-new-data-sidebar[data-v-c60db430]  .vs-sidebar .img-upload {\n  margin-top: 2rem;\n}\n[dir] .add-new-data-sidebar[data-v-c60db430]  .vs-sidebar .img-upload .con-img-upload {\n  padding: 0;\n}\n.add-new-data-sidebar[data-v-c60db430]  .vs-sidebar .img-upload .con-input-upload {\n  width: 100%;\n}\n[dir] .add-new-data-sidebar[data-v-c60db430]  .vs-sidebar .img-upload .con-input-upload {\n  margin: 0;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "#data-list-thumb-view .vs-con-table .vs-table--header {\n  display: flex;\n  flex-wrap: wrap-reverse;\n}[dir=ltr] #data-list-thumb-view .vs-con-table .vs-table--header {\n  margin-left: 1.5rem;\n  margin-right: 1.5rem;\n}[dir=rtl] #data-list-thumb-view .vs-con-table .vs-table--header {\n  margin-right: 1.5rem;\n  margin-left: 1.5rem;\n}\n#data-list-thumb-view .vs-con-table .vs-table--header > span {\n  display: flex;\n  flex-grow: 1;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search {\n  padding-top: 0;\n}\n#data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search .vs-table--search-input {\n  font-size: 1rem;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search .vs-table--search-input {\n  padding: 0.9rem 2.5rem;\n}\n[dir=ltr] #data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search .vs-table--search-input + i {\n  left: 1rem;\n}\n[dir=rtl] #data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search .vs-table--search-input + i {\n  right: 1rem;\n}\n[dir=ltr] #data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search .vs-table--search-input:focus + i {\n  left: 1rem;\n}\n[dir=rtl] #data-list-thumb-view .vs-con-table .vs-table--header .vs-table--search .vs-table--search-input:focus + i {\n  right: 1rem;\n}\n#data-list-thumb-view .vs-con-table .vs-table {\n  border-collapse: separate;\n  border-spacing: 0 1.3rem;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table {\n  padding: 0 0.6rem;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table tr {\n  box-shadow: 0 4px 20px 0 rgba(0, 0, 0, 0.05);\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table tr td {\n  padding: 0px !important;\n}\n[dir=ltr] #data-list-thumb-view .vs-con-table .vs-table tr td:first-child {\n  border-top-left-radius: 0.5rem;\n  border-bottom-left-radius: 0.5rem;\n}\n[dir=rtl] #data-list-thumb-view .vs-con-table .vs-table tr td:first-child {\n  border-top-right-radius: 0.5rem;\n  border-bottom-right-radius: 0.5rem;\n}\n[dir=ltr] #data-list-thumb-view .vs-con-table .vs-table tr td:last-child {\n  border-top-right-radius: 0.5rem;\n  border-bottom-right-radius: 0.5rem;\n}\n[dir=rtl] #data-list-thumb-view .vs-con-table .vs-table tr td:last-child {\n  border-top-left-radius: 0.5rem;\n  border-bottom-left-radius: 0.5rem;\n}\n#data-list-thumb-view .vs-con-table .vs-table tr td.img-container span {\n  display: flex;\n  justify-content: flex-start;\n}\n#data-list-thumb-view .vs-con-table .vs-table tr td.img-container .product-img {\n  height: 70px;\n}\n[dir=ltr] #data-list-thumb-view .vs-con-table .vs-table tr td.img-container .product-img {\n  padding-left: 10px;\n}\n[dir=rtl] #data-list-thumb-view .vs-con-table .vs-table tr td.img-container .product-img {\n  padding-right: 10px;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table tr td.td-check {\n  padding: 10px !important;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table--thead th {\n  padding-top: 0;\n  padding-bottom: 0;\n}\n#data-list-thumb-view .vs-con-table .vs-table--thead th .vs-table-text {\n  text-transform: uppercase;\n  font-weight: 600;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table--thead th.td-check {\n  padding: 0 15px !important;\n}\n[dir] #data-list-thumb-view .vs-con-table .vs-table--thead tr {\n  background: none;\n  box-shadow: none;\n}\n#data-list-thumb-view .vs-con-table .vs-table--pagination {\n  justify-content: center;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".leftScrol {\n  height: 80vh;\n  overflow-y: scroll;\n}\r\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/lib??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/lib??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=style&index=2&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/lib??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=template&id=c60db430&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=template&id=c60db430&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "vs-sidebar",
        {
          staticClass: "add-new-data-sidebar items-no-padding",
          attrs: {
            "click-not-close": "",
            "position-right": "",
            parent: "body",
            "default-index": "1",
            color: "primary",
            spacer: ""
          },
          model: {
            value: _vm.isSidebarActiveLocal,
            callback: function($$v) {
              _vm.isSidebarActiveLocal = $$v
            },
            expression: "isSidebarActiveLocal"
          }
        },
        [
          _c(
            "div",
            {
              staticClass:
                "mt-6 flex items-center justify-between px-6 float-right"
            },
            [
              _c("feather-icon", {
                staticClass: "cursor-pointer",
                attrs: { icon: "XIcon" },
                on: {
                  click: function($event) {
                    $event.stopPropagation()
                    _vm.isSidebarActiveLocal = false
                  }
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-tabs",
            [
              _c(
                "vs-tab",
                {
                  staticClass: "leftScrol",
                  attrs: { label: "لست نهادها", icon: "list" }
                },
                [
                  _vm.orgActiveForm
                    ? _c(
                        "div",
                        {
                          key: _vm.$vs.rtl,
                          staticClass: "scroll-area--data-list-add-new",
                          attrs: { settings: _vm.settings }
                        },
                        [
                          _c(
                            "form",
                            [
                              _c("vs-divider", [
                                _c("h4", [
                                  _vm._v(
                                    "\r\n                ویرایش معلومات نهاد\r\n              "
                                  )
                                ])
                              ]),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "p-2" },
                                [
                                  [
                                    _c("div", { staticClass: "vx-row" }, [
                                      _c(
                                        "div",
                                        {
                                          staticClass:
                                            "w-16 mx-auto flex items-center justify-center ml-5"
                                        },
                                        [
                                          _vm.oldImage
                                            ? _c("img", {
                                                staticClass: "responsive",
                                                attrs: {
                                                  src:
                                                    "/images/img/clients/" +
                                                    _vm.orgFormEdit.logo,
                                                  alt: "نشان"
                                                }
                                              })
                                            : _vm._e(),
                                          _vm._v(" "),
                                          !_vm.oldImage
                                            ? _c("img", {
                                                staticClass: "responsive",
                                                attrs: {
                                                  src: _vm.logoToChange,
                                                  alt: "نشان"
                                                }
                                              })
                                            : _vm._e()
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticClass:
                                            "modify-img flex justify-between mt-5 pt-5 ml-4"
                                        },
                                        [
                                          _c(
                                            "div",
                                            { staticClass: "mr-5 pr-5" },
                                            [
                                              _c("input", {
                                                ref: "updateImgInput1",
                                                staticClass: "hidden",
                                                attrs: {
                                                  type: "file",
                                                  accept: "image/*"
                                                },
                                                on: {
                                                  change: _vm.updateCurrImg1
                                                }
                                              }),
                                              _vm._v(" "),
                                              _c(
                                                "vs-button",
                                                {
                                                  attrs: {
                                                    icon: "edit",
                                                    color: "primary",
                                                    type: "border"
                                                  },
                                                  on: {
                                                    click: function($event) {
                                                      return _vm.$refs.updateImgInput1.click()
                                                    }
                                                  }
                                                },
                                                [_vm._v("تبدیل نشان")]
                                              )
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            { staticClass: "mr-5 pr-5" },
                                            [
                                              !_vm.oldImage
                                                ? _c(
                                                    "vs-button",
                                                    {
                                                      attrs: {
                                                        icon: "delete",
                                                        type: "border",
                                                        color: "warning"
                                                      },
                                                      on: {
                                                        click: function(
                                                          $event
                                                        ) {
                                                          return _vm.deletOnChangeLogo()
                                                        }
                                                      }
                                                    },
                                                    [_vm._v("حذف این نشان")]
                                                  )
                                                : _vm._e()
                                            ],
                                            1
                                          )
                                        ]
                                      )
                                    ])
                                  ],
                                  _vm._v(" "),
                                  _c("vs-input", {
                                    staticClass: "w-full",
                                    attrs: { label: "نام نهاد" },
                                    model: {
                                      value: _vm.orgFormEdit.name,
                                      callback: function($$v) {
                                        _vm.$set(_vm.orgFormEdit, "name", $$v)
                                      },
                                      expression: "orgFormEdit.name"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("has-error", {
                                    attrs: {
                                      form: _vm.orgFormEdit,
                                      field: "name"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("vs-input", {
                                    staticClass: "mt-2 w-full",
                                    attrs: { label: "ایمیل", type: "email" },
                                    model: {
                                      value: _vm.orgFormEdit.email,
                                      callback: function($$v) {
                                        _vm.$set(_vm.orgFormEdit, "email", $$v)
                                      },
                                      expression: "orgFormEdit.email"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("has-error", {
                                    attrs: {
                                      form: _vm.orgFormEdit,
                                      field: "email"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("vs-input", {
                                    staticClass: "mt-2 w-full",
                                    attrs: {
                                      label: " شماره تماس ",
                                      type: "text"
                                    },
                                    model: {
                                      value: _vm.orgFormEdit.phone,
                                      callback: function($$v) {
                                        _vm.$set(_vm.orgFormEdit, "phone", $$v)
                                      },
                                      expression: "orgFormEdit.phone"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("has-error", {
                                    attrs: {
                                      form: _vm.orgFormEdit,
                                      field: "phone"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("vs-input", {
                                    staticClass: "mt-2 w-full",
                                    attrs: { label: "ویب سایت", type: "text" },
                                    model: {
                                      value: _vm.orgFormEdit.website,
                                      callback: function($$v) {
                                        _vm.$set(
                                          _vm.orgFormEdit,
                                          "website",
                                          $$v
                                        )
                                      },
                                      expression: "orgFormEdit.website"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("has-error", {
                                    attrs: {
                                      form: _vm.orgFormEdit,
                                      field: "website"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("vs-input", {
                                    staticClass: "mt-2 w-full",
                                    attrs: { label: " آدرس", type: "text" },
                                    model: {
                                      value: _vm.orgFormEdit.address,
                                      callback: function($$v) {
                                        _vm.$set(
                                          _vm.orgFormEdit,
                                          "address",
                                          $$v
                                        )
                                      },
                                      expression: "orgFormEdit.address"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("has-error", {
                                    attrs: {
                                      form: _vm.orgFormEdit,
                                      field: "address"
                                    }
                                  })
                                ],
                                2
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "flex flex-wrap items-center p-2",
                                  attrs: { slot: "footer" },
                                  slot: "footer"
                                },
                                [
                                  _c(
                                    "vs-button",
                                    {
                                      staticClass: "mr-6",
                                      attrs: {
                                        type: "border",
                                        icon: "edit",
                                        color: "success"
                                      },
                                      on: {
                                        click: function($event) {
                                          return _vm.updateData()
                                        }
                                      }
                                    },
                                    [_vm._v("ویرایش")]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "vs-button",
                                    {
                                      attrs: {
                                        type: "border",
                                        icon: "close",
                                        color: "danger"
                                      },
                                      on: {
                                        click: function($event) {
                                          return _vm.resetAllState()
                                        }
                                      }
                                    },
                                    [_vm._v("بستن فورم ویرایش")]
                                  )
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c("vs-divider", [_vm._v("---")])
                            ],
                            1
                          )
                        ]
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "w-full data-list-container",
                      attrs: { id: "data-list-thumb-view" }
                    },
                    [
                      _c(
                        "vs-table",
                        {
                          ref: "table",
                          staticClass: "w-full",
                          attrs: {
                            pagination: "",
                            "max-items": 9,
                            data: _vm.clients
                          },
                          scopedSlots: _vm._u([
                            {
                              key: "default",
                              fn: function(ref) {
                                var data = ref.data
                                return [
                                  _c(
                                    "tbody",
                                    _vm._l(data, function(tr, indextr) {
                                      return _c(
                                        "vs-tr",
                                        { key: indextr, attrs: { data: tr } },
                                        [
                                          _c(
                                            "vs-td",
                                            { staticClass: "img-container" },
                                            [
                                              _c("img", {
                                                staticClass: "product-img",
                                                attrs: {
                                                  src:
                                                    "/images/img/clients/" +
                                                    tr.logo
                                                }
                                              })
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c("vs-td", [
                                            _c("span", {
                                              domProps: {
                                                textContent: _vm._s(tr.name)
                                              }
                                            })
                                          ]),
                                          _vm._v(" "),
                                          _c("vs-td", [
                                            _c(
                                              "span",
                                              [
                                                _c("vs-button", {
                                                  attrs: {
                                                    type: "border",
                                                    icon: "visibility",
                                                    size: "small",
                                                    color: "primary"
                                                  },
                                                  on: {
                                                    click: function($event) {
                                                      return _vm.showClientData(
                                                        tr.id
                                                      )
                                                    }
                                                  }
                                                })
                                              ],
                                              1
                                            )
                                          ]),
                                          _vm._v(" "),
                                          _c(
                                            "vs-td",
                                            {
                                              staticClass:
                                                "whitespace-no-wrap notupfromall"
                                            },
                                            [
                                              _c("feather-icon", {
                                                staticClass: "mr-2",
                                                attrs: {
                                                  icon: "EditIcon",
                                                  svgClasses:
                                                    "w-5 h-5 hover:text-primary stroke-current"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    $event.stopPropagation()
                                                    return _vm.editData(tr)
                                                  }
                                                }
                                              }),
                                              _vm._v(" "),
                                              _c("feather-icon", {
                                                staticClass: "ml-2",
                                                attrs: {
                                                  icon: "TrashIcon",
                                                  svgClasses:
                                                    "w-5 h-5 hover:text-danger stroke-current"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    $event.stopPropagation()
                                                    return _vm.deleteData(tr.id)
                                                  }
                                                }
                                              })
                                            ],
                                            1
                                          )
                                        ],
                                        1
                                      )
                                    }),
                                    1
                                  )
                                ]
                              }
                            }
                          ])
                        },
                        [
                          _c(
                            "template",
                            { slot: "thead" },
                            [
                              _c("vs-th", [_vm._v("نشان")]),
                              _vm._v(" "),
                              _c("vs-th", [_vm._v("نام نهاد")]),
                              _vm._v(" "),
                              _c("vs-th", [_vm._v("جزییات")]),
                              _vm._v(" "),
                              _c("vs-th", [_vm._v("بررسی")])
                            ],
                            1
                          )
                        ],
                        2
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-popup",
                        {
                          staticClass: "holamundo",
                          attrs: {
                            title: "جزییات معلومات نهاد",
                            active: _vm.popupActive
                          },
                          on: {
                            "update:active": function($event) {
                              _vm.popupActive = $event
                            }
                          }
                        },
                        _vm._l(_vm.client, function(tr, indextr) {
                          return _c("div", { key: indextr }, [
                            _c(
                              "div",
                              { staticClass: "con-expand-clients w-full" },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "con-btns-client flex items-center justify-between"
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "con-clientx flex items-center justify-start"
                                      },
                                      [
                                        _c("vs-avatar", {
                                          attrs: {
                                            size: "60px",
                                            src:
                                              "/images/img/clients/" + tr.logo
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c("span", [
                                          _c("strong", [
                                            _vm._v(_vm._s(tr.name))
                                          ])
                                        ])
                                      ],
                                      1
                                    ),
                                    _vm._v(" "),
                                    _c("div", { staticClass: "flex" })
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "vs-list",
                                  [
                                    _c("vs-list-item", {
                                      attrs: {
                                        "icon-pack": "feather",
                                        icon: "icon-mail",
                                        color: "success",
                                        title: tr.email
                                      }
                                    }),
                                    _vm._v(" "),
                                    _c("vs-list-item", {
                                      attrs: {
                                        "icon-pack": "feather",
                                        icon: "icon-globe",
                                        title: tr.website
                                      }
                                    }),
                                    _vm._v(" "),
                                    _c("vs-list-item", {
                                      attrs: {
                                        "icon-pack": "feather",
                                        icon: "icon-map-pin",
                                        title: tr.address
                                      }
                                    })
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ])
                        }),
                        0
                      )
                    ],
                    1
                  )
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                {
                  staticClass: "leftScrol",
                  attrs: { label: " اضافه کردن نهاد جدید", icon: "add" }
                },
                [
                  _c(
                    "component",
                    {
                      key: _vm.$vs.rtl,
                      staticClass: "scroll-area--data-list-add-new",
                      attrs: { settings: _vm.settings }
                    },
                    [
                      _c("form", [
                        _c(
                          "div",
                          { staticClass: "p-2" },
                          [
                            _vm.orgForm.logo
                              ? [
                                  _c("div", { staticClass: "vx-row" }, [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "img-container w-32 mx-auto flex items-center justify-center ml-5"
                                      },
                                      [
                                        _c("img", {
                                          staticClass: "responsive",
                                          attrs: {
                                            src: _vm.orgForm.logo,
                                            alt: "نشان"
                                          }
                                        })
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "modify-img flex justify-between mt-5 pt-5 ml-4"
                                      },
                                      [
                                        _c(
                                          "div",
                                          { staticClass: "mr-5 pr-5" },
                                          [
                                            _c("input", {
                                              ref: "updateImgInput",
                                              staticClass: "hidden",
                                              attrs: {
                                                type: "file",
                                                accept: "image/*"
                                              },
                                              on: { change: _vm.updateCurrImg }
                                            }),
                                            _vm._v(" "),
                                            _c(
                                              "vs-button",
                                              {
                                                attrs: {
                                                  icon: "edit",
                                                  color: "primary",
                                                  type: "border"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    return _vm.$refs.updateImgInput.click()
                                                  }
                                                }
                                              },
                                              [_vm._v("تبدیل نشان")]
                                            )
                                          ],
                                          1
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          { staticClass: "mr-5 pr-5" },
                                          [
                                            _c(
                                              "vs-button",
                                              {
                                                attrs: {
                                                  icon: "delete",
                                                  type: "border",
                                                  color: "warning"
                                                },
                                                on: {
                                                  click: function($event) {
                                                    _vm.orgForm.logo = null
                                                  }
                                                }
                                              },
                                              [_vm._v("حذف این نشان")]
                                            )
                                          ],
                                          1
                                        )
                                      ]
                                    )
                                  ])
                                ]
                              : _vm._e(),
                            _vm._v(" "),
                            _c("vs-input", {
                              staticClass: "mt-2 w-full",
                              attrs: { label: "نام نهاد" },
                              model: {
                                value: _vm.orgForm.name,
                                callback: function($$v) {
                                  _vm.$set(_vm.orgForm, "name", $$v)
                                },
                                expression: "orgForm.name"
                              }
                            }),
                            _vm._v(" "),
                            _c("has-error", {
                              attrs: { form: _vm.orgForm, field: "name" }
                            }),
                            _vm._v(" "),
                            _c("vs-input", {
                              staticClass: "mt-2 w-full",
                              attrs: { label: "ایمیل", type: "email" },
                              model: {
                                value: _vm.orgForm.email,
                                callback: function($$v) {
                                  _vm.$set(_vm.orgForm, "email", $$v)
                                },
                                expression: "orgForm.email"
                              }
                            }),
                            _vm._v(" "),
                            _c("has-error", {
                              attrs: { form: _vm.orgForm, field: "email" }
                            }),
                            _vm._v(" "),
                            _c("vs-input", {
                              staticClass: "mt-2 w-full",
                              attrs: { label: " شماره تماس ", type: "text" },
                              model: {
                                value: _vm.orgForm.phone,
                                callback: function($$v) {
                                  _vm.$set(_vm.orgForm, "phone", $$v)
                                },
                                expression: "orgForm.phone"
                              }
                            }),
                            _vm._v(" "),
                            _c("has-error", {
                              attrs: { form: _vm.orgForm, field: "phone" }
                            }),
                            _vm._v(" "),
                            _c("vs-input", {
                              staticClass: "mt-2 w-full",
                              attrs: { label: "ویب سایت", type: "text" },
                              model: {
                                value: _vm.orgForm.website,
                                callback: function($$v) {
                                  _vm.$set(_vm.orgForm, "website", $$v)
                                },
                                expression: "orgForm.website"
                              }
                            }),
                            _vm._v(" "),
                            _c("has-error", {
                              attrs: { form: _vm.orgForm, field: "website" }
                            }),
                            _vm._v(" "),
                            _c("vs-input", {
                              staticClass: "mt-2 w-full",
                              attrs: { label: " آدرس", type: "text" },
                              model: {
                                value: _vm.orgForm.address,
                                callback: function($$v) {
                                  _vm.$set(_vm.orgForm, "address", $$v)
                                },
                                expression: "orgForm.address"
                              }
                            }),
                            _vm._v(" "),
                            _c("has-error", {
                              attrs: { form: _vm.orgForm, field: "address" }
                            }),
                            _vm._v(" "),
                            !_vm.orgForm.logo
                              ? _c(
                                  "div",
                                  { staticClass: "upload-img mt-3" },
                                  [
                                    _c("input", {
                                      ref: "uploadImgInput",
                                      staticClass: "hidden",
                                      attrs: {
                                        type: "file",
                                        accept: "image/*"
                                      },
                                      on: { change: _vm.updateCurrImg }
                                    }),
                                    _vm._v(" "),
                                    _c(
                                      "vs-button",
                                      {
                                        attrs: { icon: "image" },
                                        on: {
                                          click: function($event) {
                                            return _vm.$refs.uploadImgInput.click()
                                          }
                                        }
                                      },
                                      [_vm._v("اپلود نشان")]
                                    ),
                                    _vm._v(" "),
                                    _c("has-error", {
                                      attrs: {
                                        form: _vm.orgForm,
                                        field: "logo"
                                      }
                                    })
                                  ],
                                  1
                                )
                              : _vm._e()
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "flex flex-wrap items-center p-2 mt-3",
                            attrs: { slot: "footer" },
                            slot: "footer"
                          },
                          [
                            _c(
                              "vs-button",
                              {
                                staticClass: "mr-6",
                                attrs: {
                                  type: "border",
                                  color: "success",
                                  icon: "save"
                                },
                                on: { click: _vm.submitData }
                              },
                              [_vm._v("ذخیره")]
                            )
                          ],
                          1
                        )
                      ]),
                      _vm._v(" "),
                      _c("br"),
                      _c("br")
                    ]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=template&id=f8093204&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=template&id=f8093204& ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _vm._l(_vm.items, function(i) {
        return _c(
          "div",
          { key: i.id },
          [
            _c(
              "vs-row",
              { staticClass: "pb-2 mb-2", attrs: { "vs-w": "12" } },
              [
                _c(
                  "vs-col",
                  {
                    attrs: {
                      "vs-type": "flex",
                      "vs-justify": "center",
                      "vs-align": "center",
                      "vs-lg": "3",
                      "vs-sm": "6",
                      "vs-xs": "12"
                    }
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "w-full pt-2 ml-3 mr-3" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _c("small", [_vm._v("جنس / محصول")])
                        ]),
                        _vm._v(" "),
                        _c("v-select", {
                          attrs: {
                            "get-option-label": function(option) {
                              return option.type.type + " - " + option.name
                            },
                            options: _vm.goods,
                            dir: _vm.$vs.rtl ? "rtl" : "ltr"
                          },
                          on: { input: _vm.datacalled },
                          model: {
                            value: i.item_id,
                            callback: function($$v) {
                              _vm.$set(i, "item_id", $$v)
                            },
                            expression: "i.item_id"
                          }
                        }),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "item_id" }
                        })
                      ],
                      1
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-col",
                  {
                    attrs: {
                      "vs-type": "flex",
                      "vs-justify": "center",
                      "vs-align": "center",
                      "vs-lg": "1",
                      "vs-sm": "2",
                      "vs-xs": "12"
                    }
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "w-full pt-2 ml-3 mr-3" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _c("small", [_vm._v("عملیه")])
                        ]),
                        _vm._v(" "),
                        _c("v-select", {
                          attrs: {
                            label: "title",
                            options: _vm.operations,
                            dir: _vm.$vs.rtl ? "rtl" : "ltr"
                          },
                          on: { input: _vm.operationChange },
                          model: {
                            value: i.operation_id,
                            callback: function($$v) {
                              _vm.$set(i, "operation_id", $$v)
                            },
                            expression: "i.operation_id"
                          }
                        })
                      ],
                      1
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-col",
                  {
                    attrs: {
                      "vs-type": "flex",
                      "vs-justify": "center",
                      "vs-align": "center",
                      "vs-lg": "2",
                      "vs-sm": "6",
                      "vs-xs": "12"
                    }
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "w-full pt-2 ml-3 mr-3" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _c("small", [_vm._v("مقدار")])
                        ]),
                        _vm._v(" "),
                        _c(
                          "vx-input-group",
                          {},
                          [
                            _c("template", { slot: "append" }, [
                              _c(
                                "div",
                                { staticClass: "append-text bg-primary" },
                                [
                                  _c("span", [
                                    _vm._v(
                                      _vm._s(
                                        i.item_id.uom_equiv_id
                                          ? i.item_id.uom_equiv_id.acronym
                                          : i.item_id
                                      )
                                    )
                                  ])
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("vs-input", {
                              attrs: { type: "number", min: "0" },
                              model: {
                                value: i.ammount,
                                callback: function($$v) {
                                  _vm.$set(i, "ammount", $$v)
                                },
                                expression: "i.ammount"
                              }
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "ammount" }
                        })
                      ],
                      1
                    )
                  ]
                ),
                _vm._v(" "),
                i.operation_id != undefined && i.operation_id.id == 1
                  ? _c(
                      "vs-col",
                      {
                        attrs: {
                          "vs-type": "flex",
                          "vs-justify": "center",
                          "vs-align": "center",
                          "vs-lg": "2",
                          "vs-sm": "6",
                          "vs-xs": "12"
                        }
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "w-full pt-2 ml-3 mr-3" },
                          [
                            _c("vs-input", {
                              directives: [
                                {
                                  name: "validate",
                                  rawName: "v-validate",
                                  value: "required",
                                  expression: "'required'"
                                }
                              ],
                              staticClass: "w-full",
                              attrs: { label: "ثقلت" },
                              model: {
                                value: i.density,
                                callback: function($$v) {
                                  _vm.$set(i, "density", $$v)
                                },
                                expression: "i.density"
                              }
                            }),
                            _vm._v(" "),
                            _c("has-error", {
                              attrs: { form: _vm.form, field: "density" }
                            })
                          ],
                          1
                        )
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c(
                  "vs-col",
                  {
                    attrs: {
                      "vs-type": "flex",
                      "vs-justify": "center",
                      "vs-align": "center",
                      "vs-lg": "2",
                      "vs-sm": "6",
                      "vs-xs": "12"
                    }
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "w-full pt-2 ml-3 mr-3" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _c("small", [_vm._v("معادل")])
                        ]),
                        _vm._v(" "),
                        _c(
                          "vx-input-group",
                          {},
                          [
                            _c("template", { slot: "append" }, [
                              _c(
                                "div",
                                { staticClass: "append-text bg-primary" },
                                [
                                  _c("span", [
                                    _vm._v(
                                      _vm._s(
                                        i.item_id.uom_id
                                          ? i.item_id.uom_id.acronym
                                          : i.item_id
                                      )
                                    )
                                  ])
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c("vs-input", {
                              directives: [
                                {
                                  name: "validate",
                                  rawName: "v-validate",
                                  value: "required|min:2",
                                  expression: "'required|min:2'"
                                }
                              ],
                              attrs: { type: "number" },
                              model: {
                                value: i.equivalent,
                                callback: function($$v) {
                                  _vm.$set(i, "equivalent", $$v)
                                },
                                expression: "i.equivalent"
                              }
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "equivalent" }
                        })
                      ],
                      1
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-col",
                  {
                    attrs: {
                      "vs-type": "flex",
                      "vs-justify": "center",
                      "vs-align": "center",
                      "vs-lg": "2",
                      "vs-sm": "6",
                      "vs-xs": "12"
                    }
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "w-full pt-2 ml-3 mr-3" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _c("small", [_vm._v("هزینه فی واحد")])
                        ]),
                        _vm._v(" "),
                        _c(
                          "vx-input-group",
                          {},
                          [
                            _c("template", { slot: "prepend" }, [
                              _c(
                                "div",
                                { staticClass: "prepend-text bg-primary" },
                                [_c("span", [_vm._v("AFN")])]
                              )
                            ]),
                            _vm._v(" "),
                            _c("vs-input", {
                              attrs: { type: "number" },
                              model: {
                                value: i.unit_price,
                                callback: function($$v) {
                                  _vm.$set(i, "unit_price", $$v)
                                },
                                expression: "i.unit_price"
                              }
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "unit_price" }
                        })
                      ],
                      1
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-col",
                  {
                    attrs: {
                      "vs-type": "flex",
                      "vs-justify": "center",
                      "vs-align": "center",
                      "vs-lg": "2",
                      "vs-sm": "6",
                      "vs-xs": "12"
                    }
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "w-full pt-2 ml-3 mr-3" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _c("small", [_vm._v("هزینه مجموعی")])
                        ]),
                        _vm._v(" "),
                        _c(
                          "vx-input-group",
                          {},
                          [
                            _c("template", { slot: "prepend" }, [
                              _c(
                                "div",
                                { staticClass: "prepend-text bg-primary" },
                                [_c("span", [_vm._v("AFN")])]
                              )
                            ]),
                            _vm._v(" "),
                            _c("vs-input", {
                              attrs: { type: "number" },
                              model: {
                                value: i.total_price,
                                callback: function($$v) {
                                  _vm.$set(i, "total_price", $$v)
                                },
                                expression: "i.total_price"
                              }
                            })
                          ],
                          2
                        ),
                        _vm._v(" "),
                        _c("has-error", {
                          attrs: { form: _vm.form, field: "total_price" }
                        })
                      ],
                      1
                    )
                  ]
                )
              ],
              1
            )
          ],
          1
        )
      }),
      _vm._v(" "),
      _c(
        "vs-row",
        { attrs: { "vs-w": "12" } },
        [
          _c(
            "vs-col",
            {
              staticClass: "pt-2 mb-2 ml-3 mr-3",
              attrs: {
                "vs-type": "flex",
                "vs-justify": "right",
                "vs-align": "right",
                "vs-lg": "4",
                "vs-sm": "4",
                "vs-xs": "12"
              }
            },
            [
              _c("vs-button", {
                attrs: { type: "border", color: "success", icon: "add" },
                on: { click: _vm.addNewRow }
              }),
              _vm._v("\r\n        \r\n      "),
              _c("vs-button", {
                attrs: {
                  type: "border",
                  color: "danger",
                  icon: "delete",
                  disabled: this.items.length <= 1
                },
                on: { click: _vm.removeRow }
              })
            ],
            1
          )
        ],
        1
      )
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/apps/projects/proposals/Clients.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/apps/projects/proposals/Clients.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Clients_vue_vue_type_template_id_c60db430_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Clients.vue?vue&type=template&id=c60db430&scoped=true& */ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=template&id=c60db430&scoped=true&");
/* harmony import */ var _Clients_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Clients.vue?vue&type=script&lang=js& */ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Clients.vue?vue&type=style&index=0&lang=css& */ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true& */ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true&");
/* harmony import */ var _Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Clients.vue?vue&type=style&index=2&lang=scss& */ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");








/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_5__["default"])(
  _Clients_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Clients_vue_vue_type_template_id_c60db430_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Clients_vue_vue_type_template_id_c60db430_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "c60db430",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/apps/projects/proposals/Clients.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css& ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/lib??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true&":
/*!******************************************************************************************************************************!*\
  !*** ./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true& ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/lib??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=1&id=c60db430&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_1_id_c60db430_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss& ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/lib??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=style&index=2&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/lib/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=style&index=2&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_lib_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_style_index_2_lang_scss___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=template&id=c60db430&scoped=true&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=template&id=c60db430&scoped=true& ***!
  \***************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_template_id_c60db430_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Clients.vue?vue&type=template&id=c60db430&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/projects/proposals/Clients.vue?vue&type=template&id=c60db430&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_template_id_c60db430_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Clients_vue_vue_type_template_id_c60db430_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/apps/shared/Ekmalat.vue":
/*!********************************************************!*\
  !*** ./resources/js/src/views/apps/shared/Ekmalat.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Ekmalat_vue_vue_type_template_id_f8093204___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Ekmalat.vue?vue&type=template&id=f8093204& */ "./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=template&id=f8093204&");
/* harmony import */ var _Ekmalat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ekmalat.vue?vue&type=script&lang=js& */ "./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Ekmalat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Ekmalat_vue_vue_type_template_id_f8093204___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Ekmalat_vue_vue_type_template_id_f8093204___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/apps/shared/Ekmalat.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ekmalat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Ekmalat.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Ekmalat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=template&id=f8093204&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=template&id=f8093204& ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ekmalat_vue_vue_type_template_id_f8093204___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Ekmalat.vue?vue&type=template&id=f8093204& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/apps/shared/Ekmalat.vue?vue&type=template&id=f8093204&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ekmalat_vue_vue_type_template_id_f8093204___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Ekmalat_vue_vue_type_template_id_f8093204___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);