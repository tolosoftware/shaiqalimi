<template>
  <div id="inventory-app">
    <InventoryEx></InventoryEx>
  </div>
</template>
<script>
import InventoryEx from './InventoryEx.vue'
export default {
  name: 'vx-inventory',
  components: {
    InventoryEx,
  }
}
</script>