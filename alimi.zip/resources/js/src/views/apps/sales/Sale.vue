<template>
  <SaleTabs></SaleTabs>
</template>
<script>
import SaleTabs from "./sections/SaleTabs";
export default {
  name: 'vx-sale',
  components: {
    SaleTabs
  }
}
</script>