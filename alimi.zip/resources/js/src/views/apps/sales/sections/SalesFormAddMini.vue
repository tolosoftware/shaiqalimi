<template>
  <vx-card class="height-vh-80">
    <h1 class="text-center">در حال توسعه ...</h1>
  </vx-card>
</template>
<script>
export default {
}
</script>