(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[57],{

/***/ "./resources/js/src/views/components/vuesax/breadcrumb/Breadcrumb.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/breadcrumb/Breadcrumb.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/vue-loader/lib/index.js):\nError: ENOENT: no such file or directory, open 'C:\\xampp\\htdocs\\alimi\\resources\\js\\src\\views\\components\\vuesax\\breadcrumb\\Breadcrumb.vue'");

/***/ })

}]);