(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[28],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/DashboardAnalytics.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/DashboardAnalytics.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_echarts_components_ECharts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-echarts/components/ECharts */ "./node_modules/vue-echarts/components/ECharts.vue");
/* harmony import */ var echarts_lib_component_tooltip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! echarts/lib/component/tooltip */ "./node_modules/echarts/lib/component/tooltip.js");
/* harmony import */ var echarts_lib_component_tooltip__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(echarts_lib_component_tooltip__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var echarts_lib_component_legend__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! echarts/lib/component/legend */ "./node_modules/echarts/lib/component/legend.js");
/* harmony import */ var echarts_lib_component_legend__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(echarts_lib_component_legend__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var echarts_lib_chart_line__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! echarts/lib/chart/line */ "./node_modules/echarts/lib/chart/line.js");
/* harmony import */ var echarts_lib_chart_line__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(echarts_lib_chart_line__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _theme_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./theme.json */ "./resources/js/src/views/theme.json");
var _theme_json__WEBPACK_IMPORTED_MODULE_4___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./theme.json */ "./resources/js/src/views/theme.json", 1);
/* harmony import */ var _components_statistics_cards_StatisticsCardLine_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/statistics-cards/StatisticsCardLine.vue */ "./resources/js/src/components/statistics-cards/StatisticsCardLine.vue");
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-apexcharts */ "./node_modules/vue-apexcharts/dist/vue-apexcharts.js");
/* harmony import */ var vue_apexcharts__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(vue_apexcharts__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _apexChartData_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./apexChartData.js */ "./resources/js/src/views/apexChartData.js");
/* harmony import */ var _apps_projects_proposals_ProposalList_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./apps/projects/proposals/ProposalList.vue */ "./resources/js/src/views/apps/projects/proposals/ProposalList.vue");
/* harmony import */ var _analyticsData_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./analyticsData.js */ "./resources/js/src/views/analyticsData.js");
/* harmony import */ var _components_ChangeTimeDurationDropdown_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/ChangeTimeDurationDropdown.vue */ "./resources/js/src/components/ChangeTimeDurationDropdown.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//











vue_echarts_components_ECharts__WEBPACK_IMPORTED_MODULE_0__["default"].registerTheme('ovilia-green', _theme_json__WEBPACK_IMPORTED_MODULE_4__);
/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    ECharts: vue_echarts_components_ECharts__WEBPACK_IMPORTED_MODULE_0__["default"],
    VueApexCharts: vue_apexcharts__WEBPACK_IMPORTED_MODULE_6___default.a,
    theme: _theme_json__WEBPACK_IMPORTED_MODULE_4__,
    StatisticsCardLine: _components_statistics_cards_StatisticsCardLine_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    ProjectList: _apps_projects_proposals_ProposalList_vue__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  name: 'vx-dashboard',
  data: function data() {
    return {
      apexChatData: _apexChartData_js__WEBPACK_IMPORTED_MODULE_7__["default"],
      analyticsData: _analyticsData_js__WEBPACK_IMPORTED_MODULE_9__["default"],
      // Line Charts
      siteTraffic: {},
      activeUsers: {
        series: [{
          name: 'Users',
          data: [60, 15, 58, 15, 74, 42, 82]
        }],
        analyticsData: {
          users: 97500
        }
      },
      ordersRecevied: {
        series: [{
          name: 'روز قبل',
          data: [60, 15, 58, 15, 74, 42, 82]
        }],
        analyticsData: {
          orders: 97500
        }
      },
      newsletter: {}
    };
  },
  created: function created() {
    var _this = this;

    // Support Tracker
    this.$http.get('/api/card/card-analytics/support-tracker').then(function (response) {
      _this.supportTracker = response.data;
    }).catch(function (error) {
      console.log(error);
    }); // Active Users

    this.$http.get('/api/card/card-statistics/active-users').then(function (response) {
      _this.activeUsers = response.data;
    }).catch(function (error) {
      console.log(error);
    }); // Site Traffic gained

    this.$http.get('/api/card/card-statistics/newsletter').then(function (response) {
      _this.newsletter = response.data;
    }).catch(function (error) {
      console.log(error);
    }); // Start the Progress Bar

    this.$Progress.start();
    this.$vs.loading({
      type: 'border',
      color: '#432e81'
    });
    setTimeout(function () {
      _this.$vs.loading.close();

      _this.$Progress.set(95);
    }, 2000);
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/DashboardAnalytics.vue?vue&type=template&id=596e52fc&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/DashboardAnalytics.vue?vue&type=template&id=596e52fc& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("div", { staticClass: "vx-row mb-base" }, [
        _c(
          "div",
          { staticClass: "vx-col w-full md:w-1/3 lg:w-1/3 xl:w-1/3" },
          [
            _c("statistics-card-line", {
              staticClass: "md:mb-0 mb-base",
              attrs: {
                icon: "MonitorIcon",
                "icon-right": "",
                statistic: "32476 AFN",
                statisticTitle: "مصارف",
                chartData: _vm.ordersRecevied.series
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col w-full md:w-1/3 lg:w-1/3 xl:w-1/3" },
          [
            _c("statistics-card-line", {
              staticClass: "md:mb-0 mb-base",
              attrs: {
                icon: "UserCheckIcon",
                "icon-right": "",
                statistic: "1034567 AFN",
                statisticTitle: "عواید",
                chartData: _vm.ordersRecevied.series,
                color: "success"
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col w-full md:w-1/3 lg:w-1/3 xl:w-1/3" },
          [
            _c("statistics-card-line", {
              attrs: {
                icon: "MailIcon",
                "icon-right": "",
                statistic: "76%",
                statisticTitle: "میزان مفاد دهی",
                chartData: _vm.ordersRecevied.series,
                color: "warning"
              }
            })
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "vx-row" }, [
        _c("div", { staticClass: "vx-col w-full md:w-2/3 lg:w-3/4" }, [
          _c("div", { staticClass: "vx-card mb-base" }, [
            _c("div", { staticClass: "vx-card__header" }, [
              _vm._m(0),
              _vm._v(" "),
              _c("div", { staticClass: "vx-card__actions" }, [
                _c(
                  "span",
                  { staticClass: "feather-icon select-none relative" },
                  [
                    _c(
                      "svg",
                      {
                        staticClass:
                          "feather feather-settings w-6 h-6 text-grey",
                        attrs: {
                          xmlns: "http://www.w3.org/2000/svg",
                          width: "24px",
                          height: "24px",
                          viewBox: "0 0 24 24",
                          fill: "none",
                          stroke: "currentColor",
                          "stroke-width": "2",
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round"
                        }
                      },
                      [
                        _c("circle", { attrs: { cx: "12", cy: "12", r: "3" } }),
                        _vm._v(" "),
                        _c("path", {
                          attrs: {
                            d:
                              "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"
                          }
                        })
                      ]
                    )
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "vx-card__collapsible-content vs-con-loading__container"
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "p-6 pb-0",
                    staticStyle: { position: "relative" }
                  },
                  [
                    _c("div", { staticStyle: { "min-height": "281px" } }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "apexcharts-canvas apexcharts2xlp87gwg apexcharts-theme-light",
                          staticStyle: { width: "850px", height: "266px" },
                          attrs: { id: "apexcharts2xlp87gwg" }
                        },
                        [
                          _c(
                            "svg",
                            {
                              staticClass:
                                "apexcharts-svg apexcharts-zoomable hovering-zoom",
                              staticStyle: { background: "transparent" },
                              attrs: {
                                id: "SvgjsSvg21371",
                                width: "850",
                                height: "266",
                                xmlns: "http://www.w3.org/2000/svg",
                                version: "1.1",
                                "xmlns:xlink": "http://www.w3.org/1999/xlink",
                                "xmlns:svgjs": "http://svgjs.com/svgjs",
                                "xmlns:data": "ApexChartsNS",
                                transform: "translate(0, 0)"
                              }
                            },
                            [
                              _c(
                                "g",
                                {
                                  staticClass:
                                    "apexcharts-inner apexcharts-graphical",
                                  attrs: {
                                    id: "SvgjsG21373",
                                    transform: "translate(45.9375, 30)"
                                  }
                                },
                                [
                                  _c(
                                    "defs",
                                    { attrs: { id: "SvgjsDefs21372" } },
                                    [
                                      _c(
                                        "clipPath",
                                        {
                                          attrs: { id: "gridRectMask2xlp87gwg" }
                                        },
                                        [
                                          _c("rect", {
                                            attrs: {
                                              id: "SvgjsRect21379",
                                              width: "790.046875",
                                              height: "202.98003125",
                                              x: "-4",
                                              y: "-2",
                                              rx: "0",
                                              ry: "0",
                                              opacity: "1",
                                              "stroke-width": "0",
                                              stroke: "none",
                                              "stroke-dasharray": "0",
                                              fill: "#fff"
                                            }
                                          })
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "clipPath",
                                        {
                                          attrs: {
                                            id: "gridRectMarkerMask2xlp87gwg"
                                          }
                                        },
                                        [
                                          _c("rect", {
                                            attrs: {
                                              id: "SvgjsRect21380",
                                              width: "786.046875",
                                              height: "202.98003125",
                                              x: "-2",
                                              y: "-2",
                                              rx: "0",
                                              ry: "0",
                                              opacity: "1",
                                              "stroke-width": "0",
                                              stroke: "none",
                                              "stroke-dasharray": "0",
                                              fill: "#fff"
                                            }
                                          })
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "linearGradient",
                                        {
                                          attrs: {
                                            id: "SvgjsLinearGradient21385",
                                            x1: "0",
                                            y1: "1",
                                            x2: "1",
                                            y2: "1"
                                          }
                                        },
                                        [
                                          _c("stop", {
                                            attrs: {
                                              id: "SvgjsStop21386",
                                              "stop-opacity": "1",
                                              "stop-color":
                                                "rgba(223,135,242,1)",
                                              offset: "0"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("stop", {
                                            attrs: {
                                              id: "SvgjsStop21387",
                                              "stop-opacity": "1",
                                              "stop-color":
                                                "rgba(115,103,240,1)",
                                              offset: "1"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("stop", {
                                            attrs: {
                                              id: "SvgjsStop21388",
                                              "stop-opacity": "1",
                                              "stop-color":
                                                "rgba(115,103,240,1)",
                                              offset: "1"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("stop", {
                                            attrs: {
                                              id: "SvgjsStop21389",
                                              "stop-opacity": "1",
                                              "stop-color":
                                                "rgba(223,135,242,1)",
                                              offset: "1"
                                            }
                                          })
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "filter",
                                        {
                                          attrs: {
                                            id: "SvgjsFilter21391",
                                            filterUnits: "userSpaceOnUse",
                                            width: "200%",
                                            height: "200%",
                                            x: "-50%",
                                            y: "-50%"
                                          }
                                        },
                                        [
                                          _c("feFlood", {
                                            attrs: {
                                              id: "SvgjsFeFlood21392",
                                              "flood-color": "#000000",
                                              "flood-opacity": "0.2",
                                              result: "SvgjsFeFlood21392Out",
                                              in: "SourceGraphic"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("feComposite", {
                                            attrs: {
                                              id: "SvgjsFeComposite21393",
                                              in: "SvgjsFeFlood21392Out",
                                              in2: "SourceAlpha",
                                              operator: "in",
                                              result: "SvgjsFeComposite21393Out"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("feOffset", {
                                            attrs: {
                                              id: "SvgjsFeOffset21394",
                                              dx: "2",
                                              dy: "20",
                                              result: "SvgjsFeOffset21394Out",
                                              in: "SvgjsFeComposite21393Out"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("feGaussianBlur", {
                                            attrs: {
                                              id: "SvgjsFeGaussianBlur21395",
                                              stdDeviation: "6 ",
                                              result:
                                                "SvgjsFeGaussianBlur21395Out",
                                              in: "SvgjsFeOffset21394Out"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "feMerge",
                                            {
                                              attrs: {
                                                id: "SvgjsFeMerge21396",
                                                result: "SvgjsFeMerge21396Out",
                                                in: "SourceGraphic"
                                              }
                                            },
                                            [
                                              _c("feMergeNode", {
                                                attrs: {
                                                  id: "SvgjsFeMergeNode21397",
                                                  in:
                                                    "SvgjsFeGaussianBlur21395Out"
                                                }
                                              }),
                                              _vm._v(" "),
                                              _c("feMergeNode", {
                                                attrs: {
                                                  id: "SvgjsFeMergeNode21398",
                                                  in: "[object Arguments]"
                                                }
                                              })
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c("feBlend", {
                                            attrs: {
                                              id: "SvgjsFeBlend21399",
                                              in: "SourceGraphic",
                                              in2: "SvgjsFeMerge21396Out",
                                              mode: "normal",
                                              result: "SvgjsFeBlend21399Out"
                                            }
                                          })
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c("line", {
                                    staticClass:
                                      "apexcharts-xcrosshairs apexcharts-active",
                                    attrs: {
                                      id: "SvgjsLine21378",
                                      x1: "-0.5",
                                      y1: "0",
                                      x2: "-0.5",
                                      y2: "198.98003125",
                                      stroke: "#b6b6b6",
                                      "stroke-dasharray": "3",
                                      x: "-0.5",
                                      y: "0",
                                      width: "1",
                                      height: "198.98003125",
                                      fill: "#b1b9c4",
                                      filter: "none",
                                      "fill-opacity": "0.9",
                                      "stroke-width": "1"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "g",
                                    {
                                      staticClass: "apexcharts-xaxis",
                                      attrs: {
                                        id: "SvgjsG21400",
                                        transform: "translate(0, 0)"
                                      }
                                    },
                                    [
                                      _c(
                                        "g",
                                        {
                                          staticClass:
                                            "apexcharts-xaxis-texts-g",
                                          attrs: {
                                            id: "SvgjsG21401",
                                            transform: "translate(0, -4)"
                                          }
                                        },
                                        [
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21403",
                                                x: "0",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21404",
                                                    dir: "rtl"
                                                  }
                                                },
                                                [_vm._v("Jan")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Jan")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21406",
                                                x: "71.09517045454547",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21407",
                                                    dir: "rtl"
                                                  }
                                                },
                                                [_vm._v("Feb")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Feb")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21409",
                                                x: "142.1903409090909",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21410"
                                                  }
                                                },
                                                [_vm._v("Mar")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Mar")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21412",
                                                x: "213.28551136363635",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21413"
                                                  }
                                                },
                                                [_vm._v("Apr")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Apr")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21415",
                                                x: "284.38068181818176",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21416"
                                                  }
                                                },
                                                [_vm._v("May")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("May")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21418",
                                                x: "355.4758522727272",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21419"
                                                  }
                                                },
                                                [_vm._v("Jun")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Jun")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21421",
                                                x: "426.57102272727263",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21422"
                                                  }
                                                },
                                                [_vm._v("July")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("July")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21424",
                                                x: "497.66619318181813",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21425"
                                                  }
                                                },
                                                [_vm._v("Aug")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Aug")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21427",
                                                x: "568.7613636363636",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21428"
                                                  }
                                                },
                                                [_vm._v("Sep")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Sep")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21430",
                                                x: "639.8565340909091",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21431"
                                                  }
                                                },
                                                [_vm._v("Oct")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Oct")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21433",
                                                x: "710.9517045454546",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21434"
                                                  }
                                                },
                                                [_vm._v("Nov")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Nov")])
                                            ]
                                          ),
                                          _c(
                                            "text",
                                            {
                                              staticClass:
                                                " text-grey fill-current",
                                              attrs: {
                                                id: "SvgjsText21436",
                                                x: "782.0468750000001",
                                                y: "227.98003125",
                                                "text-anchor": "middle",
                                                "dominant-baseline": "auto",
                                                "font-size": "12px",
                                                "font-weight": "400",
                                                fill: "#373d3f"
                                              }
                                            },
                                            [
                                              _c(
                                                "tspan",
                                                {
                                                  attrs: {
                                                    id: "SvgjsTspan21437"
                                                  }
                                                },
                                                [_vm._v("Dec")]
                                              ),
                                              _vm._v(" "),
                                              _c("title", [_vm._v("Dec")])
                                            ]
                                          )
                                        ]
                                      )
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "g",
                                    {
                                      staticClass: "apexcharts-grid",
                                      attrs: { id: "SvgjsG21452" }
                                    },
                                    [
                                      _c(
                                        "g",
                                        {
                                          staticClass:
                                            "apexcharts-gridlines-horizontal",
                                          attrs: { id: "SvgjsG21453" }
                                        },
                                        [
                                          _c("line", {
                                            staticClass: "apexcharts-gridline",
                                            attrs: {
                                              id: "SvgjsLine21455",
                                              x1: "0",
                                              y1: "0",
                                              x2: "782.046875",
                                              y2: "0",
                                              stroke: "#ebebeb",
                                              "stroke-dasharray": "0"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("line", {
                                            staticClass: "apexcharts-gridline",
                                            attrs: {
                                              id: "SvgjsLine21456",
                                              x1: "0",
                                              y1: "39.79600625",
                                              x2: "782.046875",
                                              y2: "39.79600625",
                                              stroke: "#ebebeb",
                                              "stroke-dasharray": "0"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("line", {
                                            staticClass: "apexcharts-gridline",
                                            attrs: {
                                              id: "SvgjsLine21457",
                                              x1: "0",
                                              y1: "79.5920125",
                                              x2: "782.046875",
                                              y2: "79.5920125",
                                              stroke: "#ebebeb",
                                              "stroke-dasharray": "0"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("line", {
                                            staticClass: "apexcharts-gridline",
                                            attrs: {
                                              id: "SvgjsLine21458",
                                              x1: "0",
                                              y1: "119.38801874999999",
                                              x2: "782.046875",
                                              y2: "119.38801874999999",
                                              stroke: "#ebebeb",
                                              "stroke-dasharray": "0"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("line", {
                                            staticClass: "apexcharts-gridline",
                                            attrs: {
                                              id: "SvgjsLine21459",
                                              x1: "0",
                                              y1: "159.184025",
                                              x2: "782.046875",
                                              y2: "159.184025",
                                              stroke: "#ebebeb",
                                              "stroke-dasharray": "0"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c("line", {
                                            staticClass: "apexcharts-gridline",
                                            attrs: {
                                              id: "SvgjsLine21460",
                                              x1: "0",
                                              y1: "198.98003125",
                                              x2: "782.046875",
                                              y2: "198.98003125",
                                              stroke: "#ebebeb",
                                              "stroke-dasharray": "0"
                                            }
                                          })
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c("g", {
                                        staticClass:
                                          "apexcharts-gridlines-vertical",
                                        attrs: { id: "SvgjsG21454" }
                                      }),
                                      _vm._v(" "),
                                      _c("line", {
                                        attrs: {
                                          id: "SvgjsLine21462",
                                          x1: "0",
                                          y1: "198.98003125",
                                          x2: "782.046875",
                                          y2: "198.98003125",
                                          stroke: "transparent",
                                          "stroke-dasharray": "0"
                                        }
                                      }),
                                      _vm._v(" "),
                                      _c("line", {
                                        attrs: {
                                          id: "SvgjsLine21461",
                                          x1: "0",
                                          y1: "1",
                                          x2: "0",
                                          y2: "198.98003125",
                                          stroke: "transparent",
                                          "stroke-dasharray": "0"
                                        }
                                      })
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "g",
                                    {
                                      staticClass:
                                        "apexcharts-line-series apexcharts-plot-series",
                                      attrs: { id: "SvgjsG21381" }
                                    },
                                    [
                                      _c(
                                        "g",
                                        {
                                          staticClass: "apexcharts-series",
                                          attrs: {
                                            id: "SvgjsG21382",
                                            seriesName: "Sales",
                                            "data:longestSeries": "true",
                                            rel: "1",
                                            "data:realIndex": "0"
                                          }
                                        },
                                        [
                                          _c("path", {
                                            staticClass: "apexcharts-line",
                                            attrs: {
                                              id: "SvgjsPath21390",
                                              d:
                                                "M 0 167.14322625C 24.88330965909091 167.14322625 46.21186079545454 135.30642125 71.09517045454545 135.30642125C 95.97848011363637 135.30642125 117.30703125 159.184025 142.1903409090909 159.184025C 167.07365056818182 159.184025 188.40220170454546 115.408418125 213.28551136363637 115.408418125C 238.1688210227273 115.408418125 259.4973721590909 151.22482374999998 284.3806818181818 151.22482374999998C 309.2639914772727 151.22482374999998 330.5925426136364 43.775606874999994 355.4758522727273 43.775606874999994C 380.3591619318182 43.775606874999994 401.68771306818184 179.08202812499997 426.57102272727275 179.08202812499997C 451.45433238636366 179.08202812499997 472.7828835227273 75.61241187499999 497.6661931818182 75.61241187499999C 522.5495028409091 75.61241187499999 543.8780539772728 115.408418125 568.7613636363636 115.408418125C 593.6446732954546 115.408418125 614.9732244318182 35.81640562499999 639.8565340909091 35.81640562499999C 664.7398437500001 35.81640562499999 686.0683948863636 87.55121374999999 710.9517045454546 87.55121374999999C 735.8350142045455 87.55121374999999 757.1635653409091 43.775606874999994 782.046875 43.775606874999994",
                                              fill: "none",
                                              "fill-opacity": "1",
                                              stroke:
                                                "url(#SvgjsLinearGradient21385)",
                                              "stroke-opacity": "1",
                                              "stroke-linecap": "butt",
                                              "stroke-width": "4",
                                              "stroke-dasharray": "0",
                                              index: "0",
                                              "clip-path":
                                                "url(#gridRectMask2xlp87gwg)",
                                              filter: "url(#SvgjsFilter21391)",
                                              pathTo:
                                                "M 0 167.14322625C 24.88330965909091 167.14322625 46.21186079545454 135.30642125 71.09517045454545 135.30642125C 95.97848011363637 135.30642125 117.30703125 159.184025 142.1903409090909 159.184025C 167.07365056818182 159.184025 188.40220170454546 115.408418125 213.28551136363637 115.408418125C 238.1688210227273 115.408418125 259.4973721590909 151.22482374999998 284.3806818181818 151.22482374999998C 309.2639914772727 151.22482374999998 330.5925426136364 43.775606874999994 355.4758522727273 43.775606874999994C 380.3591619318182 43.775606874999994 401.68771306818184 179.08202812499997 426.57102272727275 179.08202812499997C 451.45433238636366 179.08202812499997 472.7828835227273 75.61241187499999 497.6661931818182 75.61241187499999C 522.5495028409091 75.61241187499999 543.8780539772728 115.408418125 568.7613636363636 115.408418125C 593.6446732954546 115.408418125 614.9732244318182 35.81640562499999 639.8565340909091 35.81640562499999C 664.7398437500001 35.81640562499999 686.0683948863636 87.55121374999999 710.9517045454546 87.55121374999999C 735.8350142045455 87.55121374999999 757.1635653409091 43.775606874999994 782.046875 43.775606874999994",
                                              pathFrom:
                                                "M -1 278.57204375L -1 278.57204375L 71.09517045454545 278.57204375L 142.1903409090909 278.57204375L 213.28551136363637 278.57204375L 284.3806818181818 278.57204375L 355.4758522727273 278.57204375L 426.57102272727275 278.57204375L 497.6661931818182 278.57204375L 568.7613636363636 278.57204375L 639.8565340909091 278.57204375L 710.9517045454546 278.57204375L 782.046875 278.57204375"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "g",
                                            {
                                              staticClass:
                                                "apexcharts-series-markers-wrap",
                                              attrs: {
                                                id: "SvgjsG21383",
                                                "data:realIndex": "0"
                                              }
                                            },
                                            [
                                              _c(
                                                "g",
                                                {
                                                  staticClass:
                                                    "apexcharts-series-markers"
                                                },
                                                [
                                                  _c("circle", {
                                                    staticClass:
                                                      "apexcharts-marker wsy39x6sh no-pointer-events",
                                                    attrs: {
                                                      id: "SvgjsCircle21468",
                                                      r: "5",
                                                      cx: "0",
                                                      cy: "167.14322625",
                                                      stroke: "#ffffff",
                                                      fill: "#df87f2",
                                                      "fill-opacity": "1",
                                                      "stroke-width": "2",
                                                      "stroke-opacity": "0.9",
                                                      "default-marker-size": "0"
                                                    }
                                                  })
                                                ]
                                              )
                                            ]
                                          )
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c("g", {
                                        staticClass: "apexcharts-datalabels",
                                        attrs: {
                                          id: "SvgjsG21384",
                                          "data:realIndex": "0"
                                        }
                                      })
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c("line", {
                                    staticClass: "apexcharts-ycrosshairs",
                                    attrs: {
                                      id: "SvgjsLine21463",
                                      x1: "0",
                                      y1: "0",
                                      x2: "782.046875",
                                      y2: "0",
                                      stroke: "#b6b6b6",
                                      "stroke-dasharray": "0",
                                      "stroke-width": "1"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("line", {
                                    staticClass:
                                      "apexcharts-ycrosshairs-hidden",
                                    attrs: {
                                      id: "SvgjsLine21464",
                                      x1: "0",
                                      y1: "0",
                                      x2: "782.046875",
                                      y2: "0",
                                      "stroke-dasharray": "0",
                                      "stroke-width": "0"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("g", {
                                    staticClass: "apexcharts-yaxis-annotations",
                                    attrs: { id: "SvgjsG21465" }
                                  }),
                                  _vm._v(" "),
                                  _c("g", {
                                    staticClass: "apexcharts-xaxis-annotations",
                                    attrs: { id: "SvgjsG21466" }
                                  }),
                                  _vm._v(" "),
                                  _c("g", {
                                    staticClass: "apexcharts-point-annotations",
                                    attrs: { id: "SvgjsG21467" }
                                  }),
                                  _vm._v(" "),
                                  _c("rect", {
                                    staticClass: "apexcharts-zoom-rect",
                                    attrs: {
                                      id: "SvgjsRect21469",
                                      width: "0",
                                      height: "0",
                                      x: "0",
                                      y: "0",
                                      rx: "0",
                                      ry: "0",
                                      opacity: "1",
                                      "stroke-width": "0",
                                      stroke: "none",
                                      "stroke-dasharray": "0",
                                      fill: "#fefefe"
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("rect", {
                                    staticClass: "apexcharts-selection-rect",
                                    attrs: {
                                      id: "SvgjsRect21470",
                                      width: "0",
                                      height: "0",
                                      x: "0",
                                      y: "0",
                                      rx: "0",
                                      ry: "0",
                                      opacity: "1",
                                      "stroke-width": "0",
                                      stroke: "none",
                                      "stroke-dasharray": "0",
                                      fill: "#fefefe"
                                    }
                                  })
                                ]
                              ),
                              _vm._v(" "),
                              _c("rect", {
                                attrs: {
                                  id: "SvgjsRect21377",
                                  width: "0",
                                  height: "0",
                                  x: "0",
                                  y: "0",
                                  rx: "0",
                                  ry: "0",
                                  opacity: "1",
                                  "stroke-width": "0",
                                  stroke: "none",
                                  "stroke-dasharray": "0",
                                  fill: "#fefefe"
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "g",
                                {
                                  staticClass: "apexcharts-yaxis",
                                  attrs: {
                                    id: "SvgjsG21438",
                                    rel: "0",
                                    transform: "translate(15.9375, 0)"
                                  }
                                },
                                [
                                  _c(
                                    "g",
                                    {
                                      staticClass: "apexcharts-yaxis-texts-g",
                                      attrs: { id: "SvgjsG21439" }
                                    },
                                    [
                                      _c(
                                        "text",
                                        {
                                          staticClass:
                                            "apexcharts-text apexcharts-yaxis-label text-grey fill-current",
                                          attrs: {
                                            id: "SvgjsText21440",
                                            x: "20",
                                            y: "31.5",
                                            "text-anchor": "end",
                                            "dominant-baseline": "auto",
                                            "font-size": "11px",
                                            "font-weight": "400",
                                            fill: "#373d3f"
                                          }
                                        },
                                        [
                                          _c(
                                            "tspan",
                                            {
                                              attrs: { id: "SvgjsTspan21441" }
                                            },
                                            [_vm._v("350")]
                                          )
                                        ]
                                      ),
                                      _c(
                                        "text",
                                        {
                                          staticClass:
                                            "apexcharts-text apexcharts-yaxis-label text-grey fill-current",
                                          attrs: {
                                            id: "SvgjsText21442",
                                            x: "20",
                                            y: "71.29600625",
                                            "text-anchor": "end",
                                            "dominant-baseline": "auto",
                                            "font-size": "11px",
                                            "font-weight": "400",
                                            fill: "#373d3f"
                                          }
                                        },
                                        [
                                          _c(
                                            "tspan",
                                            {
                                              attrs: { id: "SvgjsTspan21443" }
                                            },
                                            [_vm._v("300")]
                                          )
                                        ]
                                      ),
                                      _c(
                                        "text",
                                        {
                                          staticClass:
                                            "apexcharts-text apexcharts-yaxis-label text-grey fill-current",
                                          attrs: {
                                            id: "SvgjsText21444",
                                            x: "20",
                                            y: "111.09201250000001",
                                            "text-anchor": "end",
                                            "dominant-baseline": "auto",
                                            "font-size": "11px",
                                            "font-weight": "400",
                                            fill: "#373d3f"
                                          }
                                        },
                                        [
                                          _c(
                                            "tspan",
                                            {
                                              attrs: { id: "SvgjsTspan21445" }
                                            },
                                            [_vm._v("250")]
                                          )
                                        ]
                                      ),
                                      _c(
                                        "text",
                                        {
                                          staticClass:
                                            "apexcharts-text apexcharts-yaxis-label text-grey fill-current",
                                          attrs: {
                                            id: "SvgjsText21446",
                                            x: "20",
                                            y: "150.88801875000001",
                                            "text-anchor": "end",
                                            "dominant-baseline": "auto",
                                            "font-size": "11px",
                                            "font-weight": "400",
                                            fill: "#373d3f"
                                          }
                                        },
                                        [
                                          _c(
                                            "tspan",
                                            {
                                              attrs: { id: "SvgjsTspan21447" }
                                            },
                                            [_vm._v("200")]
                                          )
                                        ]
                                      ),
                                      _c(
                                        "text",
                                        {
                                          staticClass:
                                            "apexcharts-text apexcharts-yaxis-label text-grey fill-current",
                                          attrs: {
                                            id: "SvgjsText21448",
                                            x: "20",
                                            y: "190.68402500000002",
                                            "text-anchor": "end",
                                            "dominant-baseline": "auto",
                                            "font-size": "11px",
                                            "font-weight": "400",
                                            fill: "#373d3f"
                                          }
                                        },
                                        [
                                          _c(
                                            "tspan",
                                            {
                                              attrs: { id: "SvgjsTspan21449" }
                                            },
                                            [_vm._v("150")]
                                          )
                                        ]
                                      ),
                                      _c(
                                        "text",
                                        {
                                          staticClass:
                                            "apexcharts-text apexcharts-yaxis-label text-grey fill-current",
                                          attrs: {
                                            id: "SvgjsText21450",
                                            x: "20",
                                            y: "230.48003125000002",
                                            "text-anchor": "end",
                                            "dominant-baseline": "auto",
                                            "font-size": "11px",
                                            "font-weight": "400",
                                            fill: "#373d3f"
                                          }
                                        },
                                        [
                                          _c(
                                            "tspan",
                                            {
                                              attrs: { id: "SvgjsTspan21451" }
                                            },
                                            [_vm._v("100")]
                                          )
                                        ]
                                      )
                                    ]
                                  )
                                ]
                              ),
                              _vm._v(" "),
                              _c("g", {
                                staticClass: "apexcharts-annotations",
                                attrs: { id: "SvgjsG21374" }
                              })
                            ]
                          ),
                          _vm._v(" "),
                          _c("div", {
                            staticClass: "apexcharts-legend",
                            staticStyle: { "max-height": "133px" }
                          }),
                          _vm._v(" "),
                          _vm._m(1),
                          _vm._v(" "),
                          _vm._m(2),
                          _vm._v(" "),
                          _vm._m(3)
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _vm._m(4)
                  ]
                )
              ]
            ),
            _vm._v(" "),
            _vm._m(5)
          ])
        ]),
        _vm._v(" "),
        _vm._m(6)
      ]),
      _vm._v(" "),
      _c("ProjectList"),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "vx-col w-full mb-base" },
        [
          _c(
            "vx-card",
            {
              attrs: {
                title: "احصائیه معاملات تجارتی دریک سال مالی",
                "code-toggler": ""
              }
            },
            [
              _c("vue-apex-charts", {
                attrs: {
                  type: "line",
                  height: "350",
                  options: _vm.apexChatData.mixedChart.chartOptions,
                  series: _vm.apexChatData.mixedChart.series
                }
              }),
              _vm._v(" "),
              _c("template", { slot: "codeContainer" }, [
                _vm._v(
                  "\r\n        " +
                    _vm._s(_vm.apexChatData.mixedChartCode) +
                    "\r\n      "
                )
              ])
            ],
            2
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "vx-card__title" }, [
      _c("h4", {}, [_vm._v("گراف فروشات")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "apexcharts-tooltip apexcharts-theme-light apexcharts-active",
        staticStyle: { left: "55.9375px", top: "169.643px" }
      },
      [
        _c(
          "div",
          {
            staticClass: "apexcharts-tooltip-series-group apexcharts-active",
            staticStyle: { order: "1", display: "flex" }
          },
          [
            _c("span", {
              staticClass: "apexcharts-tooltip-marker",
              staticStyle: { "background-color": "rgb(223, 135, 242)" }
            }),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "apexcharts-tooltip-text",
                staticStyle: {
                  "font-family": "Helvetica, Arial, sans-serif",
                  "font-size": "12px"
                }
              },
              [
                _c("div", { staticClass: "apexcharts-tooltip-y-group" }, [
                  _c("span", { staticClass: "apexcharts-tooltip-text-label" }, [
                    _vm._v("Sales: ")
                  ]),
                  _c("span", { staticClass: "apexcharts-tooltip-text-value" }, [
                    _vm._v("140")
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "apexcharts-tooltip-z-group" }, [
                  _c("span", {
                    staticClass: "apexcharts-tooltip-text-z-label"
                  }),
                  _c("span", { staticClass: "apexcharts-tooltip-text-z-value" })
                ])
              ]
            )
          ]
        )
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light apexcharts-active",
        staticStyle: { left: "25.05px", top: "230.98px" }
      },
      [
        _c(
          "div",
          {
            staticClass: "apexcharts-xaxistooltip-text",
            staticStyle: {
              "font-family": "Helvetica, Arial, sans-serif",
              "font-size": "12px",
              "min-width": "23.0781px"
            }
          },
          [_vm._v("Jan")]
        )
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light"
      },
      [_c("div", { staticClass: "apexcharts-yaxistooltip-text" })]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "resize-triggers" }, [
      _c("div", { staticClass: "expand-trigger" }, [
        _c("div", { staticStyle: { width: "892px", height: "303px" } })
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "contract-trigger" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "vx-card__code-container collapsed",
        staticStyle: { "max-height": "0px", display: "none" }
      },
      [
        _c("div", { staticClass: "code-content" }, [
          _c("pre", { staticClass: "language-markup" }, [
            _c("code", { staticClass: "language-markup" })
          ])
        ])
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      { staticClass: "vx-col w-full md:w-1/3 lg:w-1/4 xl:w-1/4" },
      [
        _c("div", { staticClass: "vx-card" }, [
          _c(
            "div",
            {
              staticClass:
                "vx-card__collapsible-content vs-con-loading__container"
            },
            [
              _c("div", { staticClass: "p-8 clearfix" }, [
                _c("div", [
                  _c("h1", [
                    _c("sup", { staticClass: "text-lg" }, [_vm._v("$")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("22,597")])
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "p",
                  { staticClass: "mt-2 mb-8 text-xl font-medium text-success" },
                  [
                    _c("span", [_vm._v("+")]),
                    _vm._v(" "),
                    _c("span", [_vm._v("5.2%")]),
                    _vm._v(" "),
                    _c("span", { staticClass: "ml-1" }, [_vm._v("($956)")])
                  ]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass:
                      "vs-component vs-button shadow-md w-full vs-button-primary vs-button-filled includeIcon",
                    attrs: { type: "button", name: "button" }
                  },
                  [
                    _c("span", {
                      staticClass:
                        "vs-button-backgroundx vs-button--background",
                      staticStyle: {
                        opacity: "1",
                        left: "137px",
                        top: "16px",
                        width: "0px",
                        height: "0px",
                        transition:
                          "width 0s ease 0s, height 0s ease 0s, opacity 0s ease 0s"
                      }
                    }),
                    _c("i", {
                      staticClass:
                        "vs-icon notranslate icon-scale vs-button--icon  feather icon-chevrons-right null",
                      staticStyle: {
                        order: "2",
                        "margin-left": "0px",
                        "margin-right": "5px"
                      }
                    }),
                    _c(
                      "span",
                      { staticClass: "vs-button-text vs-button--text" },
                      [_vm._v("برسی فروشات")]
                    ),
                    _c("span", {
                      staticClass: "vs-button-linex",
                      staticStyle: {
                        top: "auto",
                        bottom: "-2px",
                        left: "50%",
                        transform: "translate(-50%)"
                      }
                    })
                  ]
                )
              ]),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass:
                    "p-8 border d-theme-border-grey-light border-solid border-r-0 border-l-0 border-b-0"
                },
                [
                  _c("div", { staticClass: "mb-4" }, [
                    _c("small", [_vm._v("عواید: $56156")]),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        staticClass:
                          "vs-progress--background vs-progress-success",
                        staticStyle: { height: "5px" }
                      },
                      [
                        _c("div", {
                          staticClass: "vs-progress--foreground",
                          staticStyle: { width: "50%" }
                        })
                      ]
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", [
                    _c("small", [_vm._v("مدت زمان: 2 سال")]),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        staticClass:
                          "vs-progress--background vs-progress-warning",
                        staticStyle: { height: "5px" }
                      },
                      [
                        _c("div", {
                          staticClass: "vs-progress--foreground",
                          staticStyle: { width: "50%" }
                        })
                      ]
                    )
                  ])
                ]
              )
            ]
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "vx-card__code-container collapsed",
              staticStyle: { "max-height": "0px", display: "none" }
            },
            [
              _c("div", { staticClass: "code-content" }, [
                _c("pre", { staticClass: "language-markup" }, [
                  _c("code", { staticClass: "language-markup" })
                ])
              ])
            ]
          )
        ])
      ]
    )
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/DashboardAnalytics.vue":
/*!*******************************************************!*\
  !*** ./resources/js/src/views/DashboardAnalytics.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardAnalytics_vue_vue_type_template_id_596e52fc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardAnalytics.vue?vue&type=template&id=596e52fc& */ "./resources/js/src/views/DashboardAnalytics.vue?vue&type=template&id=596e52fc&");
/* harmony import */ var _DashboardAnalytics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DashboardAnalytics.vue?vue&type=script&lang=js& */ "./resources/js/src/views/DashboardAnalytics.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DashboardAnalytics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DashboardAnalytics_vue_vue_type_template_id_596e52fc___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DashboardAnalytics_vue_vue_type_template_id_596e52fc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/DashboardAnalytics.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/DashboardAnalytics.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/src/views/DashboardAnalytics.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DashboardAnalytics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./DashboardAnalytics.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/DashboardAnalytics.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DashboardAnalytics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/DashboardAnalytics.vue?vue&type=template&id=596e52fc&":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/DashboardAnalytics.vue?vue&type=template&id=596e52fc& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DashboardAnalytics_vue_vue_type_template_id_596e52fc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./DashboardAnalytics.vue?vue&type=template&id=596e52fc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/DashboardAnalytics.vue?vue&type=template&id=596e52fc&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DashboardAnalytics_vue_vue_type_template_id_596e52fc___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DashboardAnalytics_vue_vue_type_template_id_596e52fc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/analyticsData.js":
/*!*************************************************!*\
  !*** ./resources/js/src/views/analyticsData.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*=========================================================================================
  File Name: analyticsData.vue
  Description: Data shown by charts
  ----------------------------------------------------------------------------------------
  Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template
  Author: Pixinvent
  Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/
/* harmony default export */ __webpack_exports__["default"] = ({
  // LINE CHART
  siteTraffic: {
    series: [{
      name: 'Traffic Rate',
      data: [150, 200, 125, 225, 200, 250]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        type: 'line',
        dropShadow: {
          enabled: true,
          top: 5,
          left: 0,
          blur: 4,
          opacity: 0.10
        },
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      stroke: {
        width: 5,
        curve: 'smooth'
      },
      xaxis: {
        type: 'numeric'
      },
      colors: ['#7367F0'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          gradientToColors: ['#A9A2F6'],
          shadeIntensity: 1,
          type: 'horizontal',
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100, 100, 100]
        }
      },
      markers: {
        size: 0,
        hover: {
          size: 5
        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  activeUsers: {
    series: [{
      name: 'Active Users',
      data: [750, 1000, 900, 1250, 1000, 1200, 1100]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        type: 'line',
        dropShadow: {
          enabled: true,
          top: 5,
          left: 0,
          blur: 4,
          opacity: 0.10
        },
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      stroke: {
        width: 5,
        curve: 'smooth'
      },
      xaxis: {
        type: 'numeric'
      },
      colors: ['#28C76F'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          gradientToColors: ['#55DD92'],
          shadeIntensity: 1,
          type: 'horizontal',
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 75, 100, 100]
        }
      },
      markers: {
        size: 0,
        hover: {
          size: 5
        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  newsletter: {
    series: [{
      name: 'Newsletter',
      data: [365, 390, 365, 400, 375, 400]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        type: 'line',
        dropShadow: {
          enabled: true,
          top: 5,
          left: 0,
          blur: 4,
          opacity: 0.10
        },
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      stroke: {
        width: 5,
        curve: 'smooth'
      },
      xaxis: {
        type: 'numeric'
      },
      colors: ['#FF9F43'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          gradientToColors: ['#ffc085'],
          shadeIntensity: 1,
          type: 'horizontal',
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 75, 100, 100]
        }
      },
      markers: {
        size: 0,
        hover: {
          size: 5
        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  revenueComparisonLine: {
    // series: [{
    //         name: "This Month",
    //         data: [45000, 47000, 44800, 47500, 45500, 48000, 46500, 48600]
    //     },
    //     {
    //         name: "Last Month",
    //         data: [46000, 48000, 45500, 46600, 44500, 46500, 45000, 47000]
    //     }
    // ],
    chartOptions: {
      chart: {
        toolbar: {
          show: false
        },
        dropShadow: {
          enabled: true,
          top: 5,
          left: 0,
          blur: 4,
          opacity: 0.10
        }
      },
      stroke: {
        curve: 'smooth',
        dashArray: [0, 8],
        width: [4, 2]
      },
      grid: {
        borderColor: '#e7e7e7'
      },
      legend: {
        show: false
      },
      colors: ['#F97794', '#b8c2cc'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          inverseColors: false,
          gradientToColors: ['#7367F0', '#b8c2cc'],
          shadeIntensity: 1,
          type: 'horizontal',
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100, 100, 100]
        }
      },
      markers: {
        size: 0,
        hover: {
          size: 5
        }
      },
      xaxis: {
        labels: {
          style: {
            cssClass: 'text-grey fill-current'
          }
        },
        axisTicks: {
          show: false
        },
        categories: ['01', '05', '09', '13', '17', '21', '26', '31'],
        axisBorder: {
          show: false
        }
      },
      yaxis: {
        tickAmount: 5,
        labels: {
          style: {
            cssClass: 'text-grey fill-current'
          },
          formatter: function formatter(val) {
            return val > 999 ? "".concat((val / 1000).toFixed(1), "k") : val;
          }
        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  // LINE AREA CHART
  subscribersGained: {
    series: [{
      name: 'Subscribers',
      data: [28, 40, 36, 52, 38, 60, 55]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth',
        width: 2.5
      },
      fill: {
        type: 'gradient',
        gradient: {
          shadeIntensity: 0.9,
          opacityFrom: 0.7,
          opacityTo: 0.5,
          stops: [0, 80, 100]
        }
      },
      xaxis: {
        type: 'numeric',
        lines: {
          show: false
        },
        axisBorder: {
          show: false
        },
        labels: {
          show: false
        }
      },
      yaxis: [{
        y: 0,
        offsetX: 0,
        offsetY: 0,
        padding: {
          left: 0,
          right: 0
        }
      }],
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  quarterlySales: {
    series: [{
      name: 'Sales',
      data: [10, 15, 7, 12, 3, 16]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth',
        width: 2.5
      },
      fill: {
        type: 'gradient',
        gradient: {
          shadeIntensity: 0.9,
          opacityFrom: 0.7,
          opacityTo: 0.5,
          stops: [0, 80, 100]
        }
      },
      xaxis: {
        type: 'numeric',
        lines: {
          show: false
        },
        axisBorder: {
          show: false
        },
        labels: {
          show: false
        }
      },
      yaxis: [{
        y: 0,
        offsetX: 0,
        offsetY: 0,
        padding: {
          left: 0,
          right: 0
        }
      }],
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  revenueGenerated: {
    series: [{
      name: 'Revenue',
      data: [350, 275, 400, 300, 350, 300, 450]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth',
        width: 2.5
      },
      fill: {
        type: 'gradient',
        gradient: {
          shadeIntensity: 0.9,
          opacityFrom: 0.7,
          opacityTo: 0.5,
          stops: [0, 80, 100]
        }
      },
      xaxis: {
        type: 'numeric',
        lines: {
          show: false
        },
        axisBorder: {
          show: false
        },
        labels: {
          show: false
        }
      },
      yaxis: [{
        y: 0,
        offsetX: 0,
        offsetY: 0,
        padding: {
          left: 0,
          right: 0
        }
      }],
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  ordersRecevied: {
    series: [{
      name: 'Orders',
      data: [10, 15, 8, 15, 7, 12, 8]
    }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        toolbar: {
          show: false
        },
        sparkline: {
          enabled: true
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth',
        width: 2.5
      },
      fill: {
        type: 'gradient',
        gradient: {
          shadeIntensity: 0.9,
          opacityFrom: 0.7,
          opacityTo: 0.5,
          stops: [0, 80, 100]
        }
      },
      xaxis: {
        type: 'numeric',
        lines: {
          show: false
        },
        axisBorder: {
          show: false
        },
        labels: {
          show: false
        }
      },
      yaxis: [{
        y: 0,
        offsetX: 0,
        offsetY: 0,
        padding: {
          left: 0,
          right: 0
        }
      }],
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  // BAR CHART
  salesBar: {
    // series: [{
    //     name: 'Sessions',
    //     data: [75, 125, 225, 175, 125, 75, 25]
    // }],
    chartOptions: {
      grid: {
        show: false,
        padding: {
          left: 0,
          right: 0
        }
      },
      chart: {
        type: 'bar',
        sparkline: {
          enabled: true
        },
        toolbar: {
          show: false
        }
      },
      states: {
        hover: {
          filter: 'none'
        }
      },
      colors: ['rgba(115,103,240,0.15)', 'rgba(115,103,240,0.15)', '#7367f0', 'rgba(115,103,240,0.15)', 'rgba(115,103,240,0.15)', 'rgba(115,103,240,0.15)'],
      plotOptions: {
        bar: {
          columnWidth: '45%',
          distributed: true,
          endingShape: 'rounded' // Deprecated
          // borderRadius: '20px', // Coming Soon

        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  // RADIAL BAR
  goalOverviewRadialBar: {
    // series: [83],
    chartOptions: {
      plotOptions: {
        radialBar: {
          size: 110,
          startAngle: -150,
          endAngle: 150,
          hollow: {
            size: '77%'
          },
          track: {
            background: '#bfc5cc',
            strokeWidth: '50%'
          },
          dataLabels: {
            name: {
              show: false
            },
            value: {
              offsetY: 18,
              color: '#99a2ac',
              fontSize: '4rem'
            }
          }
        }
      },
      colors: ['#00db89'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          type: 'horizontal',
          shadeIntensity: 0.5,
          gradientToColors: ['#00b5b5'],
          inverseColors: true,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100]
        }
      },
      stroke: {
        lineCap: 'round'
      },
      chart: {
        sparkline: {
          enabled: true
        },
        dropShadow: {
          enabled: true,
          blur: 3,
          left: 1,
          top: 1,
          opacity: 0.1
        }
      }
    }
  },
  supportTrackerRadialBar: {
    analyticsData: {
      totalTickets: 163,
      openTickets: 103,
      lastResponse: '1d'
    },
    series: [83],
    chartOptions: {
      plotOptions: {
        radialBar: {
          size: 158,
          offsetY: -30,
          startAngle: -150,
          endAngle: 150,
          hollow: {
            size: '65%'
          },
          track: {
            background: 'rgba(0,0,0,0)',
            strokeWidth: '100%'
          },
          dataLabels: {
            value: {
              offsetY: 30,
              color: '#99a2ac',
              fontSize: '2rem'
            }
          }
        }
      },
      colors: ['#EA5455'],
      fill: {
        type: 'gradient',
        gradient: {
          // enabled: true,
          shade: 'dark',
          type: 'horizontal',
          shadeIntensity: 0.5,
          gradientToColors: ['#7367F0'],
          inverseColors: true,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100]
        }
      },
      stroke: {
        dashArray: 8
      },
      chart: {
        sparkline: {}
      },
      labels: ['Completed Tickets']
    }
  },
  // RADAR
  statisticsRadar: {
    // series: [{
    //     name: 'Visits',
    //     data: [90, 50, 86, 40, 100, 20],
    // }, {
    //     name: 'Sales',
    //     data: [70, 75, 70, 76, 20, 85],
    // }],
    chartOptions: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      dataLabels: {
        style: {
          colors: ['#b9c3cd', '#b9c3cd', '#b9c3cd', '#b9c3cd', '#b9c3cd', '#b9c3cd']
        }
      },
      yaxis: {
        show: false
      },
      grid: {
        show: false
      },
      legend: {
        show: false
      },
      chart: {
        dropShadow: {
          enabled: true,
          blur: 8,
          left: 1,
          top: 1,
          opacity: 0.2
        },
        toolbar: {
          show: false
        }
      },
      stroke: {
        width: 0
      },
      colors: ['#9f8ed7', '#1edec5'],
      plotOptions: {
        radar: {
          polygons: {
            strokeColors: ['#e8e8e8', 'transparent', 'transparent', 'transparent', 'transparent', 'transparent'],
            connectorColors: 'transparent'
          }
        }
      },
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          gradientToColors: ['#8e9ad6', '#1fcadb'],
          shadeIntensity: 1,
          type: 'horizontal',
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100, 100, 100]
        }
      },
      markers: {
        size: 0
      }
    }
  },
  // SessionsByDevice
  sessionsByDeviceDonut: {
    // analyticsData: [
    //     { device: 'Dekstop', icon: 'MonitorIcon', color: 'primary', sessionsPercentgae: 58.6, comparedResultPercentage: 2 },
    //     { device: 'Mobile', icon: 'SmartphoneIcon', color: 'warning', sessionsPercentgae: 34.9, comparedResultPercentage: 8 },
    //     { device: 'Tablet', icon: 'TabletIcon', color: 'danger', sessionsPercentgae: 6.5, comparedResultPercentage: -5 },
    // ],
    // comparedResult: [2, -3, 8],
    // series: [58.6, 34.9, 6.5],
    chartOptions: {
      labels: ['Desktop', 'Mobile', 'Tablet'],
      dataLabels: {
        enabled: false
      },
      legend: {
        show: false
      },
      chart: {
        offsetY: 30,
        type: 'donut',
        toolbar: {
          show: false
        }
      },
      stroke: {
        width: 0
      },
      colors: ['#7961F9', '#FF9F43', '#EA5455'],
      fill: {
        type: 'gradient',
        gradient: {
          gradientToColors: ['#9c8cfc', '#FFC085', '#f29292']
        }
      }
    }
  },
  // Product Orders
  productOrdersRadialBar: {
    // analyticsData: [
    //     { 'orderType': 'Finished', 'counts': 23043, color: 'primary' },
    //     { 'orderType': 'Pending', 'counts': 14658, color: 'warning' },
    //     { 'orderType': 'Rejected ', 'counts': 4758, color: 'danger' },
    // ],
    // series: [70, 52, 26],
    chartOptions: {
      labels: ['Finished', 'Pending', 'Rejected'],
      plotOptions: {
        radialBar: {
          size: 165,
          offsetY: -5,
          hollow: {
            size: '20%'
          },
          track: {
            background: '#ebebeb',
            strokeWidth: '100%',
            margin: 15
          },
          dataLabels: {
            show: true,
            name: {
              fontSize: '18px'
            },
            value: {
              fontSize: '16px',
              color: '#636a71',
              offsetY: 11
            },
            total: {
              show: true,
              label: 'Total',
              formatter: function formatter() {
                return 42459;
              }
            }
          }
        }
      },
      responsive: [{
        breakpoint: 576,
        options: {
          plotOptions: {
            radialBar: {
              size: 150,
              hollow: {
                size: '20%'
              },
              track: {
                background: '#ebebeb',
                strokeWidth: '100%',
                margin: 15
              }
            }
          }
        }
      }],
      colors: ['#7961F9', '#FF9F43', '#EA5455'],
      fill: {
        type: 'gradient',
        gradient: {
          // enabled: true,
          shade: 'dark',
          type: 'vertical',
          shadeIntensity: 0.5,
          gradientToColors: ['#9c8cfc', '#FFC085', '#f29292'],
          inverseColors: false,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100]
        }
      },
      stroke: {
        lineCap: 'round'
      },
      chart: {
        height: 355,
        dropShadow: {
          enabled: true,
          blur: 3,
          left: 1,
          top: 1,
          opacity: 0.1
        }
      }
    }
  },
  // Customers
  customersPie: {
    // analyticsData: [
    //     { 'customerType': 'New', 'counts': 890, color: 'primary' },
    //     { 'customerType': 'Returning', 'counts': 258, color: 'warning' },
    //     { 'customerType': 'Referrals ', 'counts': 149, color: 'danger' },
    // ],
    // series: [690, 258, 149],
    chartOptions: {
      labels: ['New', 'Returning', 'Referrals'],
      dataLabels: {
        enabled: false
      },
      legend: {
        show: false
      },
      chart: {
        type: 'pie',
        offsetY: 0,
        dropShadow: {
          enabled: false,
          blur: 5,
          left: 1,
          top: 1,
          opacity: 0.2
        },
        toolbar: {
          show: false
        }
      },
      stroke: {
        width: 5
      },
      colors: ['#7961F9', '#FF9F43', '#EA5455'],
      fill: {
        type: 'gradient',
        gradient: {
          gradientToColors: ['#9c8cfc', '#FFC085', '#f29292']
        }
      }
    }
  },
  // Sales monthly
  salesLine: {
    // series: [{
    //     name: "Sales",
    //     data: [140, 180, 150, 205, 160, 295, 125, 255, 205, 305, 240, 295]
    // }],
    chartOptions: {
      chart: {
        toolbar: {
          show: false
        },
        dropShadow: {
          enabled: true,
          top: 20,
          left: 2,
          blur: 6,
          opacity: 0.20
        }
      },
      stroke: {
        curve: 'smooth',
        width: 4
      },
      grid: {
        borderColor: '#ebebeb'
      },
      legend: {
        show: false
      },
      colors: ['#df87f2'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          inverseColors: false,
          gradientToColors: ['#7367F0'],
          shadeIntensity: 1,
          type: 'horizontal',
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100, 100, 100]
        }
      },
      markers: {
        size: 0,
        hover: {
          size: 5
        }
      },
      xaxis: {
        labels: {
          style: {
            cssClass: 'text-grey fill-current'
          }
        },
        axisTicks: {
          show: false
        },
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        axisBorder: {
          show: false
        }
      },
      yaxis: {
        tickAmount: 5,
        labels: {
          style: {
            cssClass: 'text-grey fill-current'
          },
          formatter: function formatter(val) {
            return val > 999 ? "".concat((val / 1000).toFixed(1), "k") : val;
          }
        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  // ClientRetention Bar Chart
  clientRetentionBar: {
    // series: [{
    //     name: 'New Clients',
    //     data: [175, 125, 225, 175, 160, 189, 206, 134, 159, 216, 148, 123]
    // }, {
    //     name: 'Retained Clients',
    //     data: [-144, -155, -141, -167, -122, -143, -158, -107, -126, -131, -140, -137]
    // }],
    chartOptions: {
      grid: {
        borderColor: '#ebebeb',
        padding: {
          left: 0,
          right: 0
        }
      },
      legend: {
        show: false
      },
      dataLabels: {
        enabled: false
      },
      chart: {
        stacked: true,
        type: 'bar',
        toolbar: {
          show: false
        }
      },
      colors: ['#7367F0', '#EA5455'],
      plotOptions: {
        bar: {
          columnWidth: '10%'
        }
      },
      xaxis: {
        labels: {
          style: {
            cssClass: 'text-grey fill-current'
          }
        },
        axisTicks: {
          show: false
        },
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        axisBorder: {
          show: false
        }
      },
      yaxis: {
        tickAmount: 5,
        labels: {
          style: {
            cssClass: 'text-grey fill-current'
          }
        }
      },
      tooltip: {
        x: {
          show: false
        }
      }
    }
  },
  // OTHER
  browserAnalytics: [{
    id: 1,
    name: 'Google Chrome',
    ratio: 73,
    time: 'Mon Dec 10 2018 07:46:05 GMT+0000 (GMT)',
    comparedResult: '800'
  }, {
    id: 3,
    name: 'Opera',
    ratio: 8,
    time: 'Mon Dec 10 2018 07:46:05 GMT+0000 (GMT)',
    comparedResult: '-200'
  }, {
    id: 2,
    name: 'Firefox',
    ratio: 19,
    time: 'Mon Dec 10 2018 07:46:05 GMT+0000 (GMT)',
    comparedResult: '100'
  }, {
    id: 4,
    name: 'Internet Explorer',
    ratio: 27,
    time: 'Mon Dec 10 2018 07:46:05 GMT+0000 (GMT)',
    comparedResult: '-450'
  }]
});

/***/ }),

/***/ "./resources/js/src/views/apexChartData.js":
/*!*************************************************!*\
  !*** ./resources/js/src/views/apexChartData.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*=========================================================================================
    File Name: apexChartData.vue
    Description: Data shown by charts
    ----------------------------------------------------------------------------------------
    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template
      Author: Pixinvent
    Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/
function generateData(baseval, count, yrange) {
  var i = 0;
  var series = [];

  while (i < count) {
    //var x =Math.floor(Math.random() * (750 - 1 + 1)) + 1;;
    var y = Math.floor(Math.random() * (yrange.max - yrange.min + 1)) + yrange.min;
    var z = Math.floor(Math.random() * (75 - 15 + 1)) + 15;
    series.push([baseval, y, z]);
    baseval += 86400000;
    i++;
  }

  return series;
}

function generateDataHeatMap(count, yrange) {
  var i = 0;
  var series = [];

  while (i < count) {
    var x = "w".concat((i + 1).toString());
    var y = Math.floor(Math.random() * (yrange.max - yrange.min + 1)) + yrange.min;
    series.push({
      x: x,
      y: y
    });
    i++;
  }

  return series;
}

var themeColors = ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E'];
/* harmony default export */ __webpack_exports__["default"] = ({
  lineChartSimple: {
    series: [{
      name: 'Desktops',
      data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
    }],
    chartOptions: {
      chart: {
        height: 350,
        zoom: {
          enabled: false
        }
      },
      colors: themeColors,
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'straight'
      },
      title: {
        text: 'بهترین محصول ماه',
        align: 'right'
      },
      grid: {
        row: {
          colors: ['#f3f3f3', 'transparent'],
          // takes an array which will be repeated on columns
          opacity: 0.5
        }
      },
      xaxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'] // categories: ['حمل', 'ثَور', 'جَوزا', 'سَرَطان', 'اَسَد', 'سُنبُله', 'مِیزان', '	عَقرَب', 'قَوس']

      }
    }
  },
  lineChartSimpleCode: "<template>\n  <vue-apex-charts type=\"line\" height=\"350\" :options=\"lineChartSimple.chartOptions\" :series=\"lineChartSimple.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      lineChartSimple: {\n        series: [{\n          name: \"Desktops\",\n          data: [10, 41, 35, 51, 49, 62, 69, 91, 148]\n        }],\n        chartOptions: {\n          chart: {\n            height: 350,\n            zoom: {\n              enabled: false\n            }\n          },\n          colors: themeColors,\n          dataLabels: {\n            enabled: false\n          },\n          stroke: {\n            curve: 'straight'\n          },\n          title: {\n            text: 'Product Trends by Month',\n            align: 'left'\n          },\n          grid: {\n            row: {\n              colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns\n              opacity: 0.5\n            },\n          },\n          xaxis: {\n            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],\n          }\n        }\n      }\n    }\n  }\n</script>",
  lineAreaChartSpline: {
    series: [{
      name: 'series1',
      data: [31, 40, 28, 51, 42, 109, 100]
    }, {
      name: 'series2',
      data: [11, 32, 45, 32, 34, 52, 41]
    }],
    chartOptions: {
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth'
      },
      colors: themeColors,
      xaxis: {
        type: 'datetime',
        categories: ['2018-09-19T00:00:00', '2018-09-19T01:30:00', '2018-09-19T02:30:00', '2018-09-19T03:30:00', '2018-09-19T04:30:00', '2018-09-19T05:30:00', '2018-09-19T06:30:00']
      },
      tooltip: {
        x: {
          format: 'dd/MM/yy HH:mm'
        }
      }
    }
  },
  lineAreaChartSplineCode: "<template>\n  <vue-apex-charts type=\"area\" height=\"350\" :options=\"lineAreaChartSpline.chartOptions\" :series=\"lineAreaChartSpline.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      lineAreaChartSpline: {\n        series: [{\n            name: 'series1',\n            data: [31, 40, 28, 51, 42, 109, 100]\n          }, {\n            name: 'series2',\n            data: [11, 32, 45, 32, 34, 52, 41]\n        }],\n        chartOptions: {\n          dataLabels: {\n            enabled: false\n          },\n          stroke: {\n            curve: 'smooth'\n          },\n          colors: themeColors,\n          xaxis: {\n            type: 'datetime',\n            categories: [\"2018-09-19T00:00:00\", \"2018-09-19T01:30:00\", \"2018-09-19T02:30:00\",\n              \"2018-09-19T03:30:00\", \"2018-09-19T04:30:00\", \"2018-09-19T05:30:00\",\n              \"2018-09-19T06:30:00\"\n            ],\n          },\n          tooltip: {\n            x: {\n              format: 'dd/MM/yy HH:mm'\n            },\n\n          }\n        }\n      }\n    }\n  }\n</script>",
  columnChart: {
    series: [{
      name: 'Net Profit',
      data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
    }, {
      name: 'Revenue',
      data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
    }, {
      name: 'Free Cash Flow',
      data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
    }],
    chartOptions: {
      colors: themeColors,
      plotOptions: {
        bar: {
          horizontal: false,
          endingShape: 'rounded',
          columnWidth: '55%'
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ['transparent']
      },
      xaxis: {
        categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
      },
      yaxis: {
        title: {
          text: '$ (thousands)'
        }
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function formatter(val) {
            return "$ ".concat(val, " thousands");
          }
        }
      }
    }
  },
  columnChartCode: "<template>\n  <vue-apex-charts type=\"bar\" height=\"350\" :options=\"columnChart.chartOptions\" :series=\"columnChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      columnChart: {\n        series: [{\n            name: 'Net Profit',\n            data: [44, 55, 57, 56, 61, 58, 63, 60, 66]\n          }, {\n            name: 'Revenue',\n            data: [76, 85, 101, 98, 87, 105, 91, 114, 94]\n          }, {\n            name: 'Free Cash Flow',\n            data: [35, 41, 36, 26, 45, 48, 52, 53, 41]\n        }],\n        chartOptions: {\n          colors: themeColors,\n          plotOptions: {\n            bar: {\n              horizontal: false,\n              endingShape: 'rounded',\n              columnWidth: '55%',\n            },\n          },\n          dataLabels: {\n            enabled: false\n          },\n          stroke: {\n            show: true,\n            width: 2,\n            colors: ['transparent']\n          },\n\n          xaxis: {\n            categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],\n          },\n          yaxis: {\n            title: {\n              text: '$ (thousands)'\n            }\n          },\n          fill: {\n            opacity: 1\n\n          },\n          tooltip: {\n            y: {\n              formatter: function(val) {\n                return \"$ \" + val + \" thousands\"\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n</script>",
  barChart: {
    series: [{
      data: [400, 430, 448, 470, 540, 580, 690, 1100, 1200, 1380]
    }],
    chartOptions: {
      colors: themeColors,
      plotOptions: {
        bar: {
          horizontal: true
        }
      },
      dataLabels: {
        enabled: false
      },
      xaxis: {
        categories: ['South Korea', 'Canada', 'United Kingdom', 'Netherlands', 'Italy', 'France', 'Japan', 'United States', 'China', 'Germany']
      }
    }
  },
  barChartCode: "<template>\n  <vue-apex-charts type=\"bar\" height=\"350\" :options=\"barChart.chartOptions\" :series=\"barChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      barChart: {\n        series: [{\n            data: [400, 430, 448, 470, 540, 580, 690, 1100, 1200, 1380]\n        }],\n        chartOptions: {\n          colors: themeColors,\n          plotOptions: {\n            bar: {\n              horizontal: true,\n            }\n          },\n          dataLabels: {\n            enabled: false\n          },\n          xaxis: {\n            categories: ['South Korea', 'Canada', 'United Kingdom', 'Netherlands', 'Italy', 'France', 'Japan',\n              'United States', 'China', 'Germany'\n            ],\n          }\n        }\n      }\n    }\n  }\n</script>",
  mixedChart: {
    series: [{
      name: 'TEAM A',
      type: 'column',
      data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30]
    }, {
      name: 'TEAM B',
      type: 'area',
      data: [44, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43]
    }, {
      name: 'TEAM C',
      type: 'line',
      data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39]
    }],
    chartOptions: {
      colors: themeColors,
      chart: {
        stacked: false
      },
      stroke: {
        width: [0, 2, 5],
        curve: 'smooth'
      },
      plotOptions: {
        bar: {
          columnWidth: '50%'
        }
      },
      fill: {
        opacity: [0.85, 0.25, 1],
        gradient: {
          inverseColors: false,
          shade: 'light',
          type: 'vertical',
          opacityFrom: 0.85,
          opacityTo: 0.55,
          stops: [0, 100, 100, 100]
        }
      },
      labels: ['01/01/2003', '02/01/2003', '03/01/2003', '04/01/2003', '05/01/2003', '06/01/2003', '07/01/2003', '08/01/2003', '09/01/2003', '10/01/2003', '11/01/2003'],
      markers: {
        size: 0
      },
      xaxis: {
        type: 'datetime'
      },
      yaxis: {
        title: {
          text: 'Points'
        },
        min: 0
      },
      tooltip: {
        shared: true,
        intersect: false,
        y: {
          formatter: function formatter(y) {
            if (typeof y !== 'undefined') {
              return "".concat(y.toFixed(0), " points");
            }

            return y;
          }
        }
      }
    }
  },
  mixedChartCode: "<template>\n  <vue-apex-charts type=\"line\" height=\"350\" :options=\"mixedChart.chartOptions\" :series=\"mixedChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      mixedChart: {\n        series: [{\n            name: 'TEAM A',\n            type: 'column',\n            data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30]\n          }, {\n            name: 'TEAM B',\n            type: 'area',\n            data: [44, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43]\n          }, {\n            name: 'TEAM C',\n            type: 'line',\n            data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39]\n        }],\n        chartOptions: {\n          colors: themeColors,\n          chart: {\n            stacked: false,\n          },\n          stroke: {\n            width: [0, 2, 5],\n            curve: 'smooth'\n          },\n          plotOptions: {\n            bar: {\n              columnWidth: '50%'\n            }\n          },\n\n          fill: {\n            opacity: [0.85, 0.25, 1],\n            gradient: {\n              inverseColors: false,\n              shade: 'light',\n              type: \"vertical\",\n              opacityFrom: 0.85,\n              opacityTo: 0.55,\n              stops: [0, 100, 100, 100]\n            }\n          },\n          labels: ['01/01/2003', '02/01/2003', '03/01/2003', '04/01/2003', '05/01/2003', '06/01/2003', '07/01/2003', '08/01/2003', '09/01/2003', '10/01/2003', '11/01/2003'],\n          markers: {\n            size: 0\n          },\n          xaxis: {\n            type: 'datetime'\n          },\n          yaxis: {\n            title: {\n              text: 'Points',\n            },\n            min: 0\n          },\n          tooltip: {\n            shared: true,\n            intersect: false,\n            y: {\n              formatter: function(y) {\n                if (typeof y !== \"undefined\") {\n                  return y.toFixed(0) + \" points\";\n                }\n                return y;\n\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n</script>",
  candlestickChart: {
    series: [{
      data: [{
        x: new Date(1538778600000),
        y: [6629.81, 6650.5, 6623.04, 6633.33]
      }, {
        x: new Date(1538780400000),
        y: [6632.01, 6643.59, 6620, 6630.11]
      }, {
        x: new Date(1538782200000),
        y: [6630.71, 6648.95, 6623.34, 6635.65]
      }, {
        x: new Date(1538784000000),
        y: [6635.65, 6651, 6629.67, 6638.24]
      }, {
        x: new Date(1538785800000),
        y: [6638.24, 6640, 6620, 6624.47]
      }, {
        x: new Date(1538787600000),
        y: [6624.53, 6636.03, 6621.68, 6624.31]
      }, {
        x: new Date(1538789400000),
        y: [6624.61, 6632.2, 6617, 6626.02]
      }, {
        x: new Date(1538791200000),
        y: [6627, 6627.62, 6584.22, 6603.02]
      }, {
        x: new Date(1538793000000),
        y: [6605, 6608.03, 6598.95, 6604.01]
      }, {
        x: new Date(1538794800000),
        y: [6604.5, 6614.4, 6602.26, 6608.02]
      }, {
        x: new Date(1538796600000),
        y: [6608.02, 6610.68, 6601.99, 6608.91]
      }, {
        x: new Date(1538798400000),
        y: [6608.91, 6618.99, 6608.01, 6612]
      }, {
        x: new Date(1538800200000),
        y: [6612, 6615.13, 6605.09, 6612]
      }, {
        x: new Date(1538802000000),
        y: [6612, 6624.12, 6608.43, 6622.95]
      }, {
        x: new Date(1538803800000),
        y: [6623.91, 6623.91, 6615, 6615.67]
      }, {
        x: new Date(1538805600000),
        y: [6618.69, 6618.74, 6610, 6610.4]
      }, {
        x: new Date(1538807400000),
        y: [6611, 6622.78, 6610.4, 6614.9]
      }, {
        x: new Date(1538809200000),
        y: [6614.9, 6626.2, 6613.33, 6623.45]
      }, {
        x: new Date(1538811000000),
        y: [6623.48, 6627, 6618.38, 6620.35]
      }, {
        x: new Date(1538812800000),
        y: [6619.43, 6620.35, 6610.05, 6615.53]
      }, {
        x: new Date(1538814600000),
        y: [6615.53, 6617.93, 6610, 6615.19]
      }, {
        x: new Date(1538816400000),
        y: [6615.19, 6621.6, 6608.2, 6620]
      }, {
        x: new Date(1538818200000),
        y: [6619.54, 6625.17, 6614.15, 6620]
      }, {
        x: new Date(1538820000000),
        y: [6620.33, 6634.15, 6617.24, 6624.61]
      }, {
        x: new Date(1538821800000),
        y: [6625.95, 6626, 6611.66, 6617.58]
      }, {
        x: new Date(1538823600000),
        y: [6619, 6625.97, 6595.27, 6598.86]
      }, {
        x: new Date(1538825400000),
        y: [6598.86, 6598.88, 6570, 6587.16]
      }, {
        x: new Date(1538827200000),
        y: [6588.86, 6600, 6580, 6593.4]
      }, {
        x: new Date(1538829000000),
        y: [6593.99, 6598.89, 6585, 6587.81]
      }, {
        x: new Date(1538830800000),
        y: [6587.81, 6592.73, 6567.14, 6578]
      }, {
        x: new Date(1538832600000),
        y: [6578.35, 6581.72, 6567.39, 6579]
      }, {
        x: new Date(1538834400000),
        y: [6579.38, 6580.92, 6566.77, 6575.96]
      }, {
        x: new Date(1538836200000),
        y: [6575.96, 6589, 6571.77, 6588.92]
      }, {
        x: new Date(1538838000000),
        y: [6588.92, 6594, 6577.55, 6589.22]
      }, {
        x: new Date(1538839800000),
        y: [6589.3, 6598.89, 6589.1, 6596.08]
      }, {
        x: new Date(1538841600000),
        y: [6597.5, 6600, 6588.39, 6596.25]
      }, {
        x: new Date(1538843400000),
        y: [6598.03, 6600, 6588.73, 6595.97]
      }, {
        x: new Date(1538845200000),
        y: [6595.97, 6602.01, 6588.17, 6602]
      }, {
        x: new Date(1538847000000),
        y: [6602, 6607, 6596.51, 6599.95]
      }, {
        x: new Date(1538848800000),
        y: [6600.63, 6601.21, 6590.39, 6591.02]
      }, {
        x: new Date(1538850600000),
        y: [6591.02, 6603.08, 6591, 6591]
      }, {
        x: new Date(1538852400000),
        y: [6591, 6601.32, 6585, 6592]
      }, {
        x: new Date(1538854200000),
        y: [6593.13, 6596.01, 6590, 6593.34]
      }, {
        x: new Date(1538856000000),
        y: [6593.34, 6604.76, 6582.63, 6593.86]
      }, {
        x: new Date(1538857800000),
        y: [6593.86, 6604.28, 6586.57, 6600.01]
      }, {
        x: new Date(1538859600000),
        y: [6601.81, 6603.21, 6592.78, 6596.25]
      }, {
        x: new Date(1538861400000),
        y: [6596.25, 6604.2, 6590, 6602.99]
      }, {
        x: new Date(1538863200000),
        y: [6602.99, 6606, 6584.99, 6587.81]
      }, {
        x: new Date(1538865000000),
        y: [6587.81, 6595, 6583.27, 6591.96]
      }, {
        x: new Date(1538866800000),
        y: [6591.97, 6596.07, 6585, 6588.39]
      }, {
        x: new Date(1538868600000),
        y: [6587.6, 6598.21, 6587.6, 6594.27]
      }, {
        x: new Date(1538870400000),
        y: [6596.44, 6601, 6590, 6596.55]
      }, {
        x: new Date(1538872200000),
        y: [6598.91, 6605, 6596.61, 6600.02]
      }, {
        x: new Date(1538874000000),
        y: [6600.55, 6605, 6589.14, 6593.01]
      }, {
        x: new Date(1538875800000),
        y: [6593.15, 6605, 6592, 6603.06]
      }, {
        x: new Date(1538877600000),
        y: [6603.07, 6604.5, 6599.09, 6603.89]
      }, {
        x: new Date(1538879400000),
        y: [6604.44, 6604.44, 6600, 6603.5]
      }, {
        x: new Date(1538881200000),
        y: [6603.5, 6603.99, 6597.5, 6603.86]
      }, {
        x: new Date(1538883000000),
        y: [6603.85, 6605, 6600, 6604.07]
      }, {
        x: new Date(1538884800000),
        y: [6604.98, 6606, 6604.07, 6606]
      }]
    }],
    chartOptions: {
      colors: themeColors,
      xaxis: {
        type: 'datetime'
      },
      yaxis: {
        tooltip: {
          enabled: true
        }
      }
    }
  },
  candlestickChartCode: "<template>\n  <vue-apex-charts type=\"candlestick\" height=\"350\" :options=\"candlestickChart.chartOptions\" :series=\"candlestickChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      candlestickChart: {\n        series: [{\n          data: [{ x: new Date(1538778600000), y: [6629.81, 6650.5, 6623.04, 6633.33] },\n            { x: new Date(1538780400000), y: [6632.01, 6643.59, 6620, 6630.11] },\n            { x: new Date(1538782200000), y: [6630.71, 6648.95, 6623.34, 6635.65] },\n            { x: new Date(1538784000000), y: [6635.65, 6651, 6629.67, 6638.24] },\n            { x: new Date(1538785800000), y: [6638.24, 6640, 6620, 6624.47] },\n            { x: new Date(1538787600000), y: [6624.53, 6636.03, 6621.68, 6624.31] },\n            { x: new Date(1538789400000), y: [6624.61, 6632.2, 6617, 6626.02] },\n            { x: new Date(1538791200000), y: [6627, 6627.62, 6584.22, 6603.02] },\n            { x: new Date(1538793000000), y: [6605, 6608.03, 6598.95, 6604.01] },\n            { x: new Date(1538794800000), y: [6604.5, 6614.4, 6602.26, 6608.02] },\n            { x: new Date(1538796600000), y: [6608.02, 6610.68, 6601.99, 6608.91] },\n            { x: new Date(1538798400000), y: [6608.91, 6618.99, 6608.01, 6612] },\n            { x: new Date(1538800200000), y: [6612, 6615.13, 6605.09, 6612] },\n            { x: new Date(1538802000000), y: [6612, 6624.12, 6608.43, 6622.95] },\n            { x: new Date(1538803800000), y: [6623.91, 6623.91, 6615, 6615.67] },\n            { x: new Date(1538805600000), y: [6618.69, 6618.74, 6610, 6610.4] },\n            { x: new Date(1538807400000), y: [6611, 6622.78, 6610.4, 6614.9] },\n            { x: new Date(1538809200000), y: [6614.9, 6626.2, 6613.33, 6623.45] },\n            { x: new Date(1538811000000), y: [6623.48, 6627, 6618.38, 6620.35] },\n            { x: new Date(1538812800000), y: [6619.43, 6620.35, 6610.05, 6615.53] },\n            { x: new Date(1538814600000), y: [6615.53, 6617.93, 6610, 6615.19] },\n            { x: new Date(1538816400000), y: [6615.19, 6621.6, 6608.2, 6620] },\n            { x: new Date(1538818200000), y: [6619.54, 6625.17, 6614.15, 6620] },\n            { x: new Date(1538820000000), y: [6620.33, 6634.15, 6617.24, 6624.61] },\n            { x: new Date(1538821800000), y: [6625.95, 6626, 6611.66, 6617.58] },\n            { x: new Date(1538823600000), y: [6619, 6625.97, 6595.27, 6598.86] },\n            { x: new Date(1538825400000), y: [6598.86, 6598.88, 6570, 6587.16] },\n            { x: new Date(1538827200000), y: [6588.86, 6600, 6580, 6593.4] },\n            { x: new Date(1538829000000), y: [6593.99, 6598.89, 6585, 6587.81] },\n            { x: new Date(1538830800000), y: [6587.81, 6592.73, 6567.14, 6578] },\n            { x: new Date(1538832600000), y: [6578.35, 6581.72, 6567.39, 6579] },\n            { x: new Date(1538834400000), y: [6579.38, 6580.92, 6566.77, 6575.96] },\n            { x: new Date(1538836200000), y: [6575.96, 6589, 6571.77, 6588.92] },\n            { x: new Date(1538838000000), y: [6588.92, 6594, 6577.55, 6589.22] },\n            { x: new Date(1538839800000), y: [6589.3, 6598.89, 6589.1, 6596.08] },\n            { x: new Date(1538841600000), y: [6597.5, 6600, 6588.39, 6596.25] },\n            { x: new Date(1538843400000), y: [6598.03, 6600, 6588.73, 6595.97] },\n            { x: new Date(1538845200000), y: [6595.97, 6602.01, 6588.17, 6602] },\n            { x: new Date(1538847000000), y: [6602, 6607, 6596.51, 6599.95] },\n            { x: new Date(1538848800000), y: [6600.63, 6601.21, 6590.39, 6591.02] },\n            { x: new Date(1538850600000), y: [6591.02, 6603.08, 6591, 6591] },\n            { x: new Date(1538852400000), y: [6591, 6601.32, 6585, 6592] },\n            { x: new Date(1538854200000), y: [6593.13, 6596.01, 6590, 6593.34] },\n            { x: new Date(1538856000000), y: [6593.34, 6604.76, 6582.63, 6593.86] },\n            { x: new Date(1538857800000), y: [6593.86, 6604.28, 6586.57, 6600.01] },\n            { x: new Date(1538859600000), y: [6601.81, 6603.21, 6592.78, 6596.25] },\n            { x: new Date(1538861400000), y: [6596.25, 6604.2, 6590, 6602.99] },\n            { x: new Date(1538863200000), y: [6602.99, 6606, 6584.99, 6587.81] },\n            { x: new Date(1538865000000), y: [6587.81, 6595, 6583.27, 6591.96] },\n            { x: new Date(1538866800000), y: [6591.97, 6596.07, 6585, 6588.39] },\n            { x: new Date(1538868600000), y: [6587.6, 6598.21, 6587.6, 6594.27] },\n            { x: new Date(1538870400000), y: [6596.44, 6601, 6590, 6596.55] },\n            { x: new Date(1538872200000), y: [6598.91, 6605, 6596.61, 6600.02] },\n            { x: new Date(1538874000000), y: [6600.55, 6605, 6589.14, 6593.01] },\n            { x: new Date(1538875800000), y: [6593.15, 6605, 6592, 6603.06] },\n            { x: new Date(1538877600000), y: [6603.07, 6604.5, 6599.09, 6603.89] },\n            { x: new Date(1538879400000), y: [6604.44, 6604.44, 6600, 6603.5] },\n            { x: new Date(1538881200000), y: [6603.5, 6603.99, 6597.5, 6603.86] },\n            { x: new Date(1538883000000), y: [6603.85, 6605, 6600, 6604.07] },\n            { x: new Date(1538884800000), y: [6604.98, 6606, 6604.07, 6606] },\n          ]\n        }],\n        chartOptions: {\n          colors: themeColors,\n          xaxis: {\n            type: 'datetime'\n          },\n          yaxis: {\n            tooltip: {\n              enabled: true\n            }\n          }\n        }\n      }\n    }\n  }\n</script>",
  bubbleChart: {
    series: [{
      name: 'Product1',
      data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {
        min: 10,
        max: 60
      })
    }, {
      name: 'Product2',
      data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {
        min: 10,
        max: 60
      })
    }, {
      name: 'Product3',
      data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {
        min: 10,
        max: 60
      })
    }, {
      name: 'Product4',
      data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {
        min: 10,
        max: 60
      })
    }],
    chartOptions: {
      colors: themeColors,
      dataLabels: {
        enabled: false
      },
      fill: {
        type: 'gradient'
      },
      xaxis: {
        tickAmount: 12,
        type: 'datetime',
        labels: {
          rotate: 0
        }
      },
      yaxis: {
        max: 70
      },
      theme: {
        palette: 'palette2'
      }
    }
  },
  bubbleChartCode: "<template>\n  <vue-apex-charts type=\"bubble\" height=\"350\" :options=\"bubbleChart.chartOptions\" :series=\"bubbleChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      bubbleChart: {\n        series: [{\n            name: 'Product1',\n            data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {\n              min: 10,\n              max: 60\n            })\n          },\n          {\n            name: 'Product2',\n            data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {\n              min: 10,\n              max: 60\n            })\n          },\n          {\n            name: 'Product3',\n            data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {\n              min: 10,\n              max: 60\n            })\n          },\n          {\n            name: 'Product4',\n            data: generateData(new Date('11 Feb 2017 GMT').getTime(), 20, {\n              min: 10,\n              max: 60\n            })\n          }\n        ],\n        chartOptions: {\n          colors: themeColors,\n          dataLabels: {\n            enabled: false\n          },\n          fill: {\n            type: 'gradient',\n          },\n          xaxis: {\n            tickAmount: 12,\n            type: 'datetime',\n\n            labels: {\n              rotate: 0,\n            }\n          },\n          yaxis: {\n            max: 70\n          },\n          theme: {\n            palette: 'palette2'\n          }\n        }\n      }\n    }\n  }\n</script>",
  scatterChart: {
    series: [{
      name: 'SAMPLE A',
      data: [[16.4, 5.4], [21.7, 2], [25.4, 3], [19, 2], [10.9, 1], [13.6, 3.2], [10.9, 7.4], [10.9, 0], [10.9, 8.2], [16.4, 0], [16.4, 1.8], [13.6, 0.3], [13.6, 0], [29.9, 0], [27.1, 2.3], [16.4, 0], [13.6, 3.7], [10.9, 5.2], [16.4, 6.5], [10.9, 0], [24.5, 7.1], [10.9, 0], [8.1, 4.7], [19, 0], [21.7, 1.8], [27.1, 0], [24.5, 0], [27.1, 0], [29.9, 1.5], [27.1, 0.8], [22.1, 2]]
    }, {
      name: 'SAMPLE B',
      data: [[6.4, 13.4], [1.7, 11], [5.4, 8], [9, 17], [1.9, 4], [3.6, 12.2], [1.9, 14.4], [1.9, 9], [1.9, 13.2], [1.4, 7], [6.4, 8.8], [3.6, 4.3], [1.6, 10], [9.9, 2], [7.1, 15], [1.4, 0], [3.6, 13.7], [1.9, 15.2], [6.4, 16.5], [0.9, 10], [4.5, 17.1], [10.9, 10], [0.1, 14.7], [9, 10], [12.7, 11.8], [2.1, 10], [2.5, 10], [27.1, 10], [2.9, 11.5], [7.1, 10.8], [2.1, 12]]
    }, {
      name: 'SAMPLE C',
      data: [[21.7, 3], [23.6, 3.5], [24.6, 3], [29.9, 3], [21.7, 20], [23, 2], [10.9, 3], [28, 4], [27.1, 0.3], [16.4, 4], [13.6, 0], [19, 5], [22.4, 3], [24.5, 3], [32.6, 3], [27.1, 4], [29.6, 6], [31.6, 8], [21.6, 5], [20.9, 4], [22.4, 0], [32.6, 10.3], [29.7, 20.8], [24.5, 0.8], [21.4, 0], [21.7, 6.9], [28.6, 7.7], [15.4, 0], [18.1, 0], [33.4, 0], [16.4, 0]]
    }],
    chartOptions: {
      colors: themeColors,
      chart: {
        zoom: {
          enabled: true,
          type: 'xy'
        }
      },
      xaxis: {
        tickAmount: 10
      },
      yaxis: {
        tickAmount: 7
      }
    }
  },
  scatterChartCode: "<template>\n  <vue-apex-charts type=\"scatter\" height=\"350\" :options=\"scatterChart.chartOptions\" :series=\"scatterChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      scatterChart: {\n        series: [{\n          name: \"SAMPLE A\",\n          data: [\n            [16.4, 5.4],\n            [21.7, 2],\n            [25.4, 3],\n            [19, 2],\n            [10.9, 1],\n            [13.6, 3.2],\n            [10.9, 7.4],\n            [10.9, 0],\n            [10.9, 8.2],\n            [16.4, 0],\n            [16.4, 1.8],\n            [13.6, 0.3],\n            [13.6, 0],\n            [29.9, 0],\n            [27.1, 2.3],\n            [16.4, 0],\n            [13.6, 3.7],\n            [10.9, 5.2],\n            [16.4, 6.5],\n            [10.9, 0],\n            [24.5, 7.1],\n            [10.9, 0],\n            [8.1, 4.7],\n            [19, 0],\n            [21.7, 1.8],\n            [27.1, 0],\n            [24.5, 0],\n            [27.1, 0],\n            [29.9, 1.5],\n            [27.1, 0.8],\n            [22.1, 2]\n          ]\n        }, {\n          name: \"SAMPLE B\",\n          data: [\n            [6.4, 13.4],\n            [1.7, 11],\n            [5.4, 8],\n            [9, 17],\n            [1.9, 4],\n            [3.6, 12.2],\n            [1.9, 14.4],\n            [1.9, 9],\n            [1.9, 13.2],\n            [1.4, 7],\n            [6.4, 8.8],\n            [3.6, 4.3],\n            [1.6, 10],\n            [9.9, 2],\n            [7.1, 15],\n            [1.4, 0],\n            [3.6, 13.7],\n            [1.9, 15.2],\n            [6.4, 16.5],\n            [0.9, 10],\n            [4.5, 17.1],\n            [10.9, 10],\n            [0.1, 14.7],\n            [9, 10],\n            [12.7, 11.8],\n            [2.1, 10],\n            [2.5, 10],\n            [27.1, 10],\n            [2.9, 11.5],\n            [7.1, 10.8],\n            [2.1, 12]\n          ]\n        }, {\n          name: \"SAMPLE C\",\n          data: [\n            [21.7, 3],\n            [23.6, 3.5],\n            [24.6, 3],\n            [29.9, 3],\n            [21.7, 20],\n            [23, 2],\n            [10.9, 3],\n            [28, 4],\n            [27.1, 0.3],\n            [16.4, 4],\n            [13.6, 0],\n            [19, 5],\n            [22.4, 3],\n            [24.5, 3],\n            [32.6, 3],\n            [27.1, 4],\n            [29.6, 6],\n            [31.6, 8],\n            [21.6, 5],\n            [20.9, 4],\n            [22.4, 0],\n            [32.6, 10.3],\n            [29.7, 20.8],\n            [24.5, 0.8],\n            [21.4, 0],\n            [21.7, 6.9],\n            [28.6, 7.7],\n            [15.4, 0],\n            [18.1, 0],\n            [33.4, 0],\n            [16.4, 0]\n          ]\n        }],\n        chartOptions: {\n          colors: themeColors,\n          chart: {\n            zoom: {\n              enabled: true,\n              type: 'xy'\n            }\n          },\n          xaxis: {\n            tickAmount: 10,\n          },\n          yaxis: {\n            tickAmount: 7\n          }\n        }\n      }\n    }\n  }\n</script>",
  heatMapChart: {
    series: [{
      name: 'Metric1',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric2',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric3',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric4',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric5',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric6',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric7',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric8',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }, {
      name: 'Metric9',
      data: generateDataHeatMap(18, {
        min: 0,
        max: 90
      })
    }],
    chartOptions: {
      dataLabels: {
        enabled: false
      },
      colors: ['#7367F0']
    }
  },
  heatMapChartCode: "<template>\n  <vue-apex-charts type=\"heatmap\" height=\"350\" :options=\"heatMapChart.chartOptions\" :series=\"heatMapChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      heatMapChart: {\n        series: [{\n            name: 'Metric1',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric2',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric3',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric4',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric5',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric6',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric7',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric8',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          },\n          {\n            name: 'Metric9',\n            data: generateDataHeatMap(18, {\n              min: 0,\n              max: 90\n            })\n          }\n          ],\n        chartOptions: {\n          colors: themeColors,\n          dataLabels: {\n            enabled: false\n          },\n          colors: [\"#008FFB\"],\n        }\n      }\n    }\n  }\n</script>",
  pieChart: {
    series: [44, 55, 13, 43],
    chartOptions: {
      labels: ['Team A', 'Team B', 'Team C', 'Team D'],
      colors: themeColors,
      responsive: [{
        breakpoint: 480,
        options: {
          chart: {
            width: 200
          },
          legend: {
            position: 'bottom'
          }
        }
      }]
    }
  },
  pieChartCode: "<template>\n  <vue-apex-charts type=\"pie\" height=\"350\" :options=\"pieChart.chartOptions\" :series=\"pieChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      pieChart: {\n        series: [44, 55, 13, 43],\n        chartOptions: {\n          labels: ['Team A', 'Team B', 'Team C', 'Team D'],\n          colors: themeColors,\n          responsive: [{\n            breakpoint: 480,\n            options: {\n              chart: {\n                width: 200\n              },\n              legend: {\n                position: 'bottom'\n              }\n            }\n          }]\n        }\n      }\n    }\n  }\n</script>",
  donutChart: {
    series: [44, 55, 41, 17],
    chartOptions: {
      colors: themeColors,
      responsive: [{
        breakpoint: 480,
        options: {
          chart: {
            width: 200
          },
          legend: {
            position: 'bottom'
          }
        }
      }]
    }
  },
  donutChartCode: "<template>\n  <vue-apex-charts type=\"donut\" height=\"350\" :options=\"donutChart.chartOptions\" :series=\"donutChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      donutChart: {\n        series: [44, 55, 41, 17],\n        chartOptions: {\n          colors: themeColors,\n          responsive: [{\n            breakpoint: 480,\n            options: {\n              chart: {\n                width: 200\n              },\n              legend: {\n                position: 'bottom'\n              }\n            }\n          }]\n        }\n      }\n    }\n  }\n</script>",
  radialBarChart: {
    series: [44, 55, 67, 83],
    chartOptions: {
      colors: themeColors,
      plotOptions: {
        radialBar: {
          dataLabels: {
            name: {
              fontSize: '22px'
            },
            value: {
              fontSize: '16px'
            },
            total: {
              show: true,
              label: 'Total',
              formatter: function formatter() {
                // By default this function returns the average of all series. The below is just an example to show the use of custom formatter function
                return 249;
              }
            }
          }
        }
      },
      labels: ['Apples', 'Oranges', 'Bananas', 'Berries']
    }
  },
  radialBarChartCode: "<template>\n  <vue-apex-charts type=\"radialBar\" height=\"350\" :options=\"radialBarChart.chartOptions\" :series=\"radialBarChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      radialBarChart: {\n        series: [44, 55, 67, 83],\n        chartOptions: {\n          colors: themeColors,\n          plotOptions: {\n            radialBar: {\n              dataLabels: {\n                name: {\n                  fontSize: '22px',\n                },\n                value: {\n                  fontSize: '16px',\n                },\n                total: {\n                  show: true,\n                  label: 'Total',\n                  formatter: function(w) {\n                    // By default this function returns the average of all series. The below is just an example to show the use of custom formatter function\n                    return 249\n                  }\n                }\n              }\n            }\n          },\n          labels: ['Apples', 'Oranges', 'Bananas', 'Berries'],\n        }\n      }\n    }\n  }\n</script>",
  radarChart: {
    series: [{
      name: 'Series 1',
      data: [80, 50, 30, 40, 100, 20]
    }],
    chartOptions: {
      colors: themeColors,
      labels: ['January', 'February', 'March', 'April', 'May', 'June']
    }
  },
  radarChartCode: "<template>\n  <vue-apex-charts type=\"radar\" height=\"350\" :options=\"radarChart.chartOptions\" :series=\"radarChart.series\"></vue-apex-charts>\n</template>\n\n<script>\n  data() {\n    return {\n      themeColors: ['#7367F0', '#28C76F', '#EA5455', '#FF9F43', '#1E1E1E']\n      radarChart: {\n        series: [{\n          name: 'Series 1',\n          data: [80, 50, 30, 40, 100, 20],\n        }],\n        chartOptions: {\n          colors: themeColors,\n          labels: ['January', 'February', 'March', 'April', 'May', 'June'],\n        }\n      }\n    }\n  }\n</script>"
});

/***/ }),

/***/ "./resources/js/src/views/theme.json":
/*!*******************************************!*\
  !*** ./resources/js/src/views/theme.json ***!
  \*******************************************/
/*! exports provided: color, backgroundColor, textStyle, title, line, radar, bar, pie, scatter, boxplot, parallel, sankey, funnel, gauge, candlestick, graph, map, geo, categoryAxis, valueAxis, logAxis, timeAxis, toolbox, legend, tooltip, timeline, visualMap, dataZoom, markPoint, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"color\":[\"#4ea397\",\"#22c3aa\",\"#7bd9a5\"],\"backgroundColor\":\"rgba(0,0,0,0)\",\"textStyle\":{},\"title\":{\"textStyle\":{\"color\":\"#666666\"},\"subtextStyle\":{\"color\":\"#999999\"}},\"line\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"2\"}},\"lineStyle\":{\"normal\":{\"width\":\"3\"}},\"symbolSize\":\"10\",\"symbol\":\"emptyCircle\",\"smooth\":false},\"radar\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"2\"}},\"lineStyle\":{\"normal\":{\"width\":\"3\"}},\"symbolSize\":\"10\",\"symbol\":\"emptyCircle\",\"smooth\":true},\"bar\":{\"itemStyle\":{\"normal\":{\"barBorderWidth\":\"0\",\"barBorderColor\":\"#444444\"},\"emphasis\":{\"barBorderWidth\":\"0\",\"barBorderColor\":\"#444444\"}}},\"pie\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"scatter\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"boxplot\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"parallel\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"sankey\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"funnel\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"gauge\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"},\"emphasis\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}}},\"candlestick\":{\"itemStyle\":{\"normal\":{\"color\":\"#d0648a\",\"color0\":\"#ffffff\",\"borderColor\":\"#d0648a\",\"borderColor0\":\"#22c3aa\",\"borderWidth\":1}}},\"graph\":{\"itemStyle\":{\"normal\":{\"borderWidth\":\"0\",\"borderColor\":\"#444444\"}},\"lineStyle\":{\"normal\":{\"width\":1,\"color\":\"#aaa\"}},\"symbolSize\":\"10\",\"symbol\":\"emptyCircle\",\"smooth\":true,\"color\":[\"#4ea397\",\"#22c3aa\",\"#7bd9a5\"],\"label\":{\"normal\":{\"textStyle\":{\"color\":\"#ffffff\"}}}},\"map\":{\"itemStyle\":{\"normal\":{\"areaColor\":\"#eeeeee\",\"borderColor\":\"#999999\",\"borderWidth\":\"0.5\"},\"emphasis\":{\"areaColor\":\"rgba(34,195,170,0.25)\",\"borderColor\":\"#22c3aa\",\"borderWidth\":\"0.5\"}},\"label\":{\"normal\":{\"textStyle\":{\"color\":\"#28544e\"}},\"emphasis\":{\"textStyle\":{\"color\":\"rgb(52,158,142)\"}}}},\"geo\":{\"itemStyle\":{\"normal\":{\"areaColor\":\"#eeeeee\",\"borderColor\":\"#999999\",\"borderWidth\":\"0.5\"},\"emphasis\":{\"areaColor\":\"rgba(34,195,170,0.25)\",\"borderColor\":\"#22c3aa\",\"borderWidth\":\"0.5\"}},\"label\":{\"normal\":{\"textStyle\":{\"color\":\"#28544e\"}},\"emphasis\":{\"textStyle\":{\"color\":\"rgb(52,158,142)\"}}}},\"categoryAxis\":{\"axisLine\":{\"show\":true,\"lineStyle\":{\"color\":\"#cccccc\"}},\"axisTick\":{\"show\":false,\"lineStyle\":{\"color\":\"#333333\"}},\"axisLabel\":{\"show\":true,\"textStyle\":{\"color\":\"#999999\"}},\"splitLine\":{\"show\":true,\"lineStyle\":{\"color\":[\"#eeeeee\"]}},\"splitArea\":{\"show\":false,\"areaStyle\":{\"color\":[\"rgba(250,250,250,0.3)\",\"rgba(200,200,200,0.3)\"]}}},\"valueAxis\":{\"axisLine\":{\"show\":true,\"lineStyle\":{\"color\":\"#cccccc\"}},\"axisTick\":{\"show\":false,\"lineStyle\":{\"color\":\"#333333\"}},\"axisLabel\":{\"show\":true,\"textStyle\":{\"color\":\"#999999\"}},\"splitLine\":{\"show\":true,\"lineStyle\":{\"color\":[\"#eeeeee\"]}},\"splitArea\":{\"show\":false,\"areaStyle\":{\"color\":[\"rgba(250,250,250,0.3)\",\"rgba(200,200,200,0.3)\"]}}},\"logAxis\":{\"axisLine\":{\"show\":true,\"lineStyle\":{\"color\":\"#cccccc\"}},\"axisTick\":{\"show\":false,\"lineStyle\":{\"color\":\"#333333\"}},\"axisLabel\":{\"show\":true,\"textStyle\":{\"color\":\"#999999\"}},\"splitLine\":{\"show\":true,\"lineStyle\":{\"color\":[\"#eeeeee\"]}},\"splitArea\":{\"show\":false,\"areaStyle\":{\"color\":[\"rgba(250,250,250,0.3)\",\"rgba(200,200,200,0.3)\"]}}},\"timeAxis\":{\"axisLine\":{\"show\":true,\"lineStyle\":{\"color\":\"#cccccc\"}},\"axisTick\":{\"show\":false,\"lineStyle\":{\"color\":\"#333333\"}},\"axisLabel\":{\"show\":true,\"textStyle\":{\"color\":\"#999999\"}},\"splitLine\":{\"show\":true,\"lineStyle\":{\"color\":[\"#eeeeee\"]}},\"splitArea\":{\"show\":false,\"areaStyle\":{\"color\":[\"rgba(250,250,250,0.3)\",\"rgba(200,200,200,0.3)\"]}}},\"toolbox\":{\"iconStyle\":{\"normal\":{\"borderColor\":\"#aaaaaa\"},\"emphasis\":{\"borderColor\":\"#666\"}}},\"legend\":{\"textStyle\":{\"color\":\"#999999\"}},\"tooltip\":{\"axisPointer\":{\"lineStyle\":{\"color\":\"#ccc\",\"width\":1},\"crossStyle\":{\"color\":\"#ccc\",\"width\":1}}},\"timeline\":{\"lineStyle\":{\"color\":\"#349e8e\",\"width\":1},\"itemStyle\":{\"normal\":{\"color\":\"#349e8e\",\"borderWidth\":\"1\"},\"emphasis\":{\"color\":\"#57e8d2\"}},\"controlStyle\":{\"normal\":{\"color\":\"#349e8e\",\"borderColor\":\"#349e8e\",\"borderWidth\":\"0\"}},\"checkpointStyle\":{\"color\":\"#22c3aa\",\"borderColor\":\"rgba(34,195,170,0.25)\"},\"label\":{\"normal\":{\"textStyle\":{\"color\":\"#349e8e\"}}}},\"visualMap\":{\"color\":[\"#d0648a\",\"#22c3aa\",\"rgba(123,217,165,0.2)\"]},\"dataZoom\":{\"backgroundColor\":\"#fff\",\"dataBackgroundColor\":\"#dedede\",\"fillerColor\":\"rgba(34,195,170,0.25)\",\"handleColor\":\"#dddddd\",\"handleSize\":\"100%\",\"textStyle\":{\"color\":\"#999\"}},\"markPoint\":{\"label\":{\"normal\":{\"textStyle\":{\"color\":\"#ffffff\"}},\"emphasis\":{\"textStyle\":{\"color\":\"#ffffff\"}}}}}");

/***/ })

}]);